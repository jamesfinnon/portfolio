package species;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.InputMismatchException;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JScrollPane;
import javax.swing.JTable;

/**
 * a class containing the fields and methods used for the database. This includes menus as well as their respective actions
 * 
 * @author J. Finnon
 * @version 1.0
 */
public class PlantSpeciesDatabase 
{
	//creates an ArrayList of plantSpecies
	private ArrayList<PlantSpecies> allPlants = new ArrayList<PlantSpecies>();
	
	//creates a blank plant which can be later used when adding new plants to the databas
	
	//scanner for user input
	private static Scanner s = new Scanner(System.in);
	
	
	/**
	 * deafault constructor to setup the database. There are no fields which need to be initialised at this point, so the 'setupCollection' method is called
	 */
	public PlantSpeciesDatabase()
	{
		setupCollection();
	}
	
	/**
	 * sets up the database with initial entries according to the user
	 */
	public void setupCollection()
	{
		int initialNumEntries;
		
		System.out.print("How many plants would you like to initially add to the database: ");
		initialNumEntries = s.nextInt();
		
		for(int i = 0; i < initialNumEntries; i++)
		{
			addPlant();
		}
	}
	
	/**
	 * method to add a plant to the database
	 */
	public void addPlant()
	{
		//temporary plant which will then be added to the ArrayList (database)
		//initialised with default values
		PlantSpecies newPlant = new PlantSpecies();
		
		//the following variables are declared here as they are used in multiple private methods called from this public method
		
		//number of plants in ArrayList (database)
		int numPlants = allPlants.size();
		//same number in string format for outputting to user
		String numPlantsStr = Integer.toString(numPlants + 1);
		
		//populates the newPlant object with user input
		//where necessary, inputs are validated by their associated methods
		newPlant.setSpeciesName(getNewSpeciesName(numPlants, numPlantsStr));
		newPlant.setRegion(getNewRegion(numPlants, numPlantsStr));
		newPlant.setLeavesLength(getNewLeavesLength(numPlantsStr));
		newPlant.setLeavesWidth(getNewLeavesWidth(numPlantsStr));
		
		//adds the temporary plant to the database
		allPlants.add(newPlant);
	}
	
	/**
	 * method to get the species name from the user
	 * 
	 * @param numPlants Number of entries in the database
	 * @param numPlantsStr Same number in string form
	 * @return The validated species name inputed by the user
	 */
	private String getNewSpeciesName(int numPlants, String numPlantsStr)
	{
		String newSpeciesName;
		
		//variable for input validation
		boolean valid = true;
		
		//input validation loop
		do
		{
			valid = true;
					
			System.out.print("Please enter the scientific species name for plant number " + numPlantsStr + ": ");
			newSpeciesName = s.next();
			
			//checks if species name is in the database
			valid = validateSpeciesName(newSpeciesName, numPlants);
					
			if(!valid)
			{
				System.out.println("Error. Species name already found in database.");
			}
		}	
		while(!valid);
		
		return newSpeciesName;
	}
	

	/**
	 * method to check if species name entered by the user already exists in the database
	 * 
	 * @param speciesName To be validated
	 * @param numPlants Number of plants in the database
	 * @return Whether or not the entered name is valid
	 */
	private boolean validateSpeciesName(String speciesName, int numPlants)
	{
		boolean valid = true;
		
		//loop to check all entries in the database
		for (int i = 0; i <= numPlants - 1; i++)
		{
			//check if name exists somewhere in database
			if (allPlants.get(i).getSpeciesName().equals(speciesName))
			{
				valid = false;
				break;
			}
		}
		//return true or false depending on validity
		return valid;
	}
	
	/**
	 * method to get new region from the user
	 * 
	 * @param numPlants Number of plants in the database
	 * @param numPlantsStr Same number in string form
	 * @return
	 */
	private String getNewRegion(int numPlants, String numPlantsStr)
	{
		//no input validation is necessary
		System.out.print("Please enter the region in which plant number " + numPlantsStr + " was found: ");
		return s.next();
	}
	
	/**
	 * method to get new leaves length from the user
	 * 
	 * @param numPlantsStr Number of plants in the database in string form
	 * @return The inputed leaves length
	 */
	private double getNewLeavesLength(String numPlantsStr)
	{
		
		double newLeavesLength = 0;
		
		//variable for input validation
		boolean valid = true;
		
		//input validation loop
		do
		{
			valid = true;
			
			System.out.print("Please enter the length of the leaves for plant number " + numPlantsStr + " (value between 1.5-25000mm): ");
			try {
				newLeavesLength = s.nextDouble();
			}
			catch(InputMismatchException e)
			{
				//give error
				System.out.println("Error. Input must be a decimal value.");
				//clear scanner
				s.nextLine();
				//invalidate input
				valid = false;
				//retry
				continue;
			}			
			
			//validate input is in range
			valid = validateDouble(newLeavesLength, 1.3, 25000);
			
			if(!valid)
			{
				System.out.println("Error. Value entered was not between 1.5 and 25000mm.");
			}
		}
		while(!valid);
		
		return newLeavesLength;
	}
	
	/**
	 * method to get new leaves width from the user
	 * 
	 * @param numPlantsStr Number of plants in the database in string form
	 * @return The inputed leaves width
	 */
	private double getNewLeavesWidth(String numPlantsStr)
	{
		
		double newLeavesWidth = 0;
		
		//variable for input validation
		boolean valid = true;
		
		//input validation loop
		do
		{
			valid = true;
			
			System.out.print("Please enter the width of the leaves for plant number " + numPlantsStr + " (value between 1-3000mm): ");
			try {
				newLeavesWidth = s.nextDouble();
			}
			catch(InputMismatchException e)
			{
				//give error
				System.out.println("Error. Input must be a decimal value.");
				//clear scanner
				s.nextLine();
				//invalidate input
				valid = false;
				//retry
				continue;
			}
			
			//validate input is in range
			valid = validateDouble(newLeavesWidth, 1, 3000);
			
			if(!valid)
			{
				System.out.println("Error. Value entered was not between 1 and 3000mm.");
			}
		}
		while(!valid);
		
		return newLeavesWidth;
	}
	
	/**
	 * method to validate user input for double
	 * 
	 * @param userInput Double entered by user
	 * @param min of range
	 * @param max of range
	 * @return Boolean if valid
	 */
	private boolean validateDouble(double userInput, double min, double max)
	{
		boolean valid = true;
		
		if((userInput < min) || (userInput > max))
		{
			valid = false;
		}
		
		return valid;
	}
	
	/**
	 * method to display collection in table
	 */
	private void displayCollection()
	{
		//creates empty window
		JFrame frame = new JFrame("Plant Species Database");
		
		//creates table with values from methods
		JTable table = new JTable(getWholeCollection(), getColumnHeaders());
		//allows scrolling if window is not large enough
		JScrollPane scrollPane = new JScrollPane(table);
		//ensures table scales to window size
        table.setFillsViewportHeight(true);
        
        //table header
        JLabel lblHeading = new JLabel("Entire Database");
        
        //creates the table layout
        frame.getContentPane().setLayout(new BorderLayout());
        frame.getContentPane().add(lblHeading,BorderLayout.PAGE_START);
        frame.getContentPane().add(scrollPane,BorderLayout.CENTER);
        
        //set window size
        frame.setSize(1500, 750);
        //display to user
        frame.setVisible(true);
	}
	
	/**
	 * method to get the column headers for all tables
	 * a method is used here as it is easier to read, and can be reused for different tables
	 * 
	 * @return an array of strings containing the column headers
	 */
	private String[] getColumnHeaders()
	{
		//column headers in order
		String[] columnHeaders = {"Species Name", "Region", "Leaves Length (mm)", "Leaves Width (mm)", "Leaf Area (mm^2)", "Evaporation Rate Per Day (mm)"};
		
		return columnHeaders;
	}
	
	/**
	 * method to retrieve the entire database, and place it in a 2d array
	 * 
	 * @return database in 2d array
	 */
	private Object[][] getWholeCollection()
	{
		
		Object[][] rowData = new Object[allPlants.size()][6];
		
		for(int i = 0; i < allPlants.size(); i++)
		{
			rowData[i][0] = allPlants.get(i).getSpeciesName();
			rowData[i][1] = allPlants.get(i).getRegion();
			rowData[i][2] = allPlants.get(i).getLeavesLength();
			rowData[i][3] = allPlants.get(i).getLeavesWidth();
			rowData[i][4] = allPlants.get(i).getLeafArea();
			rowData[i][5] = allPlants.get(i).getEvaporationRate();
		}
		
		return rowData;
	}
	
	/* ATTEMPETD WILDCARD SEARCH
	
	private void displaySearch(String target)
	{
		ArrayList<Integer> indexFound = new ArrayList<Integer>();
		
		indexFound = Algorithms.linearSearchSpeciesName(target, allPlants);
		
		if (indexFound.size() == 0)
		{
			System.out.println("Plant not found.");
		}
		else
		{
			Object[][] rowData = new Object[indexFound.size()][6];
			
			for (int i = 0; i < indexFound.size(); i++)
			{
				rowData[i][0] = allPlants.get(indexFound.get(i)).getSpeciesName();
				rowData[i][1] = allPlants.get(indexFound.get(i)).getRegion();
				rowData[i][2] = allPlants.get(indexFound.get(i)).getLeavesLength();
				rowData[i][3] = allPlants.get(indexFound.get(i)).getLeavesWidth();
				rowData[i][4] = allPlants.get(indexFound.get(i)).getLeafArea();
				rowData[i][5] = allPlants.get(indexFound.get(i)).getEvaporationRate();
			}
			
			JFrame frame = new JFrame("Plant Species Database");
			
			JTable table = new JTable(rowData, getColumnHeaders());
			JScrollPane scrollPane = new JScrollPane(table);
	        table.setFillsViewportHeight(true);
	        
	        JLabel lblHeading = new JLabel("Search for " + target);

	        frame.getContentPane().setLayout(new BorderLayout());

	        frame.getContentPane().add(lblHeading,BorderLayout.PAGE_START);
	        frame.getContentPane().add(scrollPane,BorderLayout.CENTER);
	        
	        frame.setSize(1500, 750);
	        frame.setVisible(true);
			
		}
		
		
	}
	
	*/
	
	/**
	 * method to display a table of results from a search
	 * 
	 * @param target Searched keyword
	 * @param searchBy Species name (0) or region (1)
	 */
	private void displaySearch(String target, int searchBy)
	{
		//arraylist for indices of successful searches
		ArrayList<Integer> indexFound = new ArrayList<Integer>();
		
		//search by species name or region
		if (searchBy == 0)
		{
			indexFound = Algorithms.linearSearchSpeciesName(target, allPlants);
		}
		else
		{
			indexFound = Algorithms.linearSearchRegion(target, allPlants);
		}
		
		//if nothing is in indexFound, no entries have been found
		if (indexFound.size() == 0)
		{
			System.out.println("Entry not found.");
		}
		else
		{
			//populate 2d array with all data found from successful search
			Object[][] rowData = new Object[indexFound.size()][6];
			
			for (int i = 0; i < indexFound.size(); i++)
			{
				rowData[i][0] = allPlants.get(indexFound.get(i)).getSpeciesName();
				rowData[i][1] = allPlants.get(indexFound.get(i)).getRegion();
				rowData[i][2] = allPlants.get(indexFound.get(i)).getLeavesLength();
				rowData[i][3] = allPlants.get(indexFound.get(i)).getLeavesWidth();
				rowData[i][4] = allPlants.get(indexFound.get(i)).getLeafArea();
				rowData[i][5] = allPlants.get(indexFound.get(i)).getEvaporationRate();
			}
			
			//create empty window
			JFrame frame = new JFrame("Plant Species Database");
			
			//create table with searched data and column headers
			JTable table = new JTable(rowData, getColumnHeaders());
			//allows scrolling
			JScrollPane scrollPane = new JScrollPane(table);
			//ensures table fills screen
	        table.setFillsViewportHeight(true);
	        
	        //table heading with searched term
	        JLabel lblHeading = new JLabel("Search for " + target);
	        
	        //creates the table layout
	        frame.getContentPane().setLayout(new BorderLayout());
	        frame.getContentPane().add(lblHeading,BorderLayout.PAGE_START);
	        frame.getContentPane().add(scrollPane,BorderLayout.CENTER);
	        
	        //sets window size
	        frame.setSize(1500, 750);
	        //displays table to user
	        frame.setVisible(true);
			
		}	
	}
	
	/**
	 * method to remove plant from database
	 */
	private void deletePlant()
	{
		String target;
		boolean found = false;
		
		System.out.print("Enter the species name of the plant you would like to delete: ");
		target = s.next();
		
		//linear search to find and remove plant
		for (int i = 0; i < allPlants.size(); i++)
		{
			if (target.equals(allPlants.get(i).getSpeciesName()))
			{
				allPlants.remove(i);
				System.out.println("Entry Successfully removed.");
				found = true;
				break;
			}
		}
		
		//display error message if plant not found
		if (!found)
		{
			System.out.println("Error. Entry was not found.");
		}	
	}
	
	
	/**
	 * method containing main menu
	 * 
	 * @param database The database that the menu's options will interact with
	 * @return the menu to the user
	 */
	public static JMenuBar databaseOptions(PlantSpeciesDatabase database)
	{
		
		JMenuBar menuBar = new JMenuBar();
		JMenu menu, submenu;
		JMenuItem menuItem;
		
		//FILE
		
		//top level entry
		menu = new JMenu("File");
        menuBar.add(menu);
        
        //exit option
        menuItem = new JMenuItem("Exit");
        menuItem.addActionListener(new ActionListener() 
        {
        	/**
        	 * method to run when exit is pressed
        	 * will exit program
        	 * 
        	 * @param e
        	 */
        	public void actionPerformed(ActionEvent e) 
        	{
        	    System.exit(0);
        	}
        
        });
        menu.add(menuItem);
		
        //EDIT COLLECTION
        
        //top level entry
		menu = new JMenu("Edit Collection");
        menuBar.add(menu);
        
        //option to add new plant
        menuItem = new JMenuItem("Add new plant...");
        menuItem.addActionListener(new ActionListener() 
        {
        	/**
        	 * method to run when Add new plant is pressed
        	 * will run method to add new plant
        	 * 
        	 * @param e
        	 */
        	public void actionPerformed(ActionEvent e) 
        	{
        	    database.addPlant();
        	}
        
        });  
        menu.add(menuItem);
        
        //option to delete a plant
        menuItem = new JMenuItem("Delete a plant...");
        menuItem.addActionListener(new ActionListener() 
        {
        	/**
        	 * method to run when Delete plant is pressed
        	 * will run method to remove plant
        	 * 
        	 * @param e
        	 */
        	public void actionPerformed(ActionEvent e) 
        	{
        	    database.deletePlant();
        	}
        
        });  
        menu.add(menuItem);
        
        //Submenu in edit collection for sorting options
        
        menu.addSeparator();
        submenu = new JMenu("Sort By");
        
        //following lines are all options for sorting by different things
        
        menuItem = new JMenuItem("Species Name...");
        menuItem.addActionListener(new ActionListener() 
        {
        	/**
        	 * method to sort by species name
        	 * 
        	 * @param e
        	 */
        	public void actionPerformed(ActionEvent e) 
        	{
        		Collections.sort(database.allPlants, Comparator.comparing(PlantSpecies::getSpeciesName));
        		
        		System.out.println("Database successfully sorted by species name.");
        	}
        
        });
        submenu.add(menuItem);
        
        menuItem = new JMenuItem("Region...");
        menuItem.addActionListener(new ActionListener() 
        {
        	/**
        	 * method to sort by region
        	 * 
        	 * @param e
        	 */
        	public void actionPerformed(ActionEvent e) 
        	{
        		Collections.sort(database.allPlants, Comparator.comparing(PlantSpecies::getRegion));
        		
        		System.out.println("Database successfully sorted by region.");
        	}
        
        });
        submenu.add(menuItem);
        
        menuItem = new JMenuItem("Leaves Length...");
        menuItem.addActionListener(new ActionListener() 
        {
        	
        	/**
        	 * method to sort by leaves length
        	 * 
        	 * @param e
        	 */
        	public void actionPerformed(ActionEvent e) 
        	{
        		Collections.sort(database.allPlants, Comparator.comparing(PlantSpecies::getLeavesLength));
        		
        		System.out.println("Database successfully sorted by the length of the leaves.");
        	}
        
        });
        submenu.add(menuItem);
        
        menuItem = new JMenuItem("Leaves Width...");
        menuItem.addActionListener(new ActionListener() 
        {
        	
        	/**
        	 * method to sort by leaves width
        	 * 
        	 * @param e
        	 */
        	public void actionPerformed(ActionEvent e) 
        	{
        		Collections.sort(database.allPlants, Comparator.comparing(PlantSpecies::getLeavesWidth));
        		
        		System.out.println("Database successfully sorted by the width of the leaves.");
        	}
        
        });
        submenu.add(menuItem);
        
        menuItem = new JMenuItem("Leaf Area...");
        menuItem.addActionListener(new ActionListener() 
        {
        	
        	/**
        	 * method to sort by leaf area
        	 * 
        	 * @param e
        	 */
        	public void actionPerformed(ActionEvent e) 
        	{
        		Collections.sort(database.allPlants, Comparator.comparing(PlantSpecies::getLeafArea));
        		
        		System.out.println("Database successfully sorted by area of the leaf.");
        	}
        
        });
        submenu.add(menuItem);
        
        menuItem = new JMenuItem("Evaporation Rate...");
        menuItem.addActionListener(new ActionListener() 
        {
        	
        	/**
        	 * method to sort by evaporation rate
        	 * 
        	 * @param e
        	 */
        	public void actionPerformed(ActionEvent e) 
        	{
        		Collections.sort(database.allPlants, Comparator.comparing(PlantSpecies::getEvaporationRate));
        		
        		System.out.println("Database successfully sorted by the evaporation rate.");
        	}
        
        });
        submenu.add(menuItem);
        
        menu.add(submenu);
        
        //VIEW COLLECTION
        
        //top level entry
        menu = new JMenu("View Collection");
        menuBar.add(menu);
        
        //option to view whole collection
        menuItem = new JMenuItem("View Entire Collection...");
        menuItem.addActionListener(new ActionListener() 
        {
        	/**
        	 * method to run when user presses View Entire Collection
        	 * will run method to display collection table to user
        	 * 
        	 * @param e
        	 */
        	public void actionPerformed(ActionEvent e) 
        	{
        	    database.displayCollection();
        	}
        
        });
        menu.add(menuItem);
        
        //submenu to search for entries
        menu.addSeparator();
        submenu = new JMenu("Search By");
        
        //option to search by species name
        menuItem = new JMenuItem("Species Name...");
        menuItem.addActionListener(new ActionListener() 
        {
        	/**
        	 * method to allow the user to search the database for a specific species name, and display entries to user
        	 * 
        	 * @param e
        	 */
        	public void actionPerformed(ActionEvent e) 
        	{
        		String target;
        		
        	    System.out.print("Please enter the species you are searching for: ");
        	    target = s.next();
        	    
        	    database.displaySearch(target, 0);
        	}
        
        });
        submenu.add(menuItem);
        
        //option to search by region
        menuItem = new JMenuItem("Region...");
        menuItem.addActionListener(new ActionListener() 
        {
        	/**
        	 * method to allow the user to search the database for a specific region
        	 * will display multiple entries if they share a region
        	 * 
        	 * @param e
        	 */
        	public void actionPerformed(ActionEvent e) 
        	{
        		String target;
        		
        	    System.out.print("Please enter the region you are searching for: ");
        	    target = s.next();
        	    
        	    database.displaySearch(target, 1);
        	}
        
        });
        submenu.add(menuItem);
        
        menu.add(submenu);
        
        //send the menu to the user
		return menuBar;		
	}
	
	
	/**
	 * main method
	 * 
	 * @param args
	 */
	public static void main(String[] args) 
	{
		//creates an instance of the PlantSpeciesDatabase
		PlantSpeciesDatabase database = new PlantSpeciesDatabase();
		
		//creates menu frame
        final JFrame frame = new JFrame("Plant Species Database");
        //creates menu
        frame.setJMenuBar(databaseOptions(database));

        //sets menu size
        frame.setSize(500, 300);
        //displays menu to user
        frame.setVisible(true);
	}
	
}
