package species;


/**
 * a class used to represent and record information for a single plant for the plants in the database
 * 
 * @author J. Finnon
 * @version 1.0
 */
public class PlantSpecies 
{
	private String speciesName;
	private String region;
	private double leavesLength;
	private double leavesWidth;
	
	private double leafArea;
	private double evaporationRate;
	
	
	//getters for all fields
	
	
	/**
	 * get and return the species name
	 * 
	 * @return the plant's scientific species name
	 */
	public String getSpeciesName()
	{
		return speciesName;
	}
	
	/**
	 * get and return the region
	 * 
	 * @return the plant's region
	 */
	public String getRegion()
	{
		return region;
	}
	
	/**
	 * get and return the length of the leaves
	 * 
	 * @return the length of the leaves
	 */
	public double getLeavesLength()
	{
		return leavesLength;
	}
	
	/**
	 * get and return the width of the leaves
	 * 
	 * @return the width of the leaves
	 */
	public double getLeavesWidth()
	{
		return leavesWidth;
	}
	
	/**
	 * get and return the area of the leaf
	 * 
	 * @return the area of the leaf
	 */
	public double getLeafArea()
	{
		return leafArea;
	}
	
	/**
	 * @return the evaporation rate of the leaf
	 */
	public double getEvaporationRate()
	{
		return evaporationRate;
	}
	
	//setters for all fields
	
	
	/**
	 * set the species name
	 * 
	 * @param newSpeciesName The new name of the species (scientific)
	 */
	public void setSpeciesName(String newSpeciesName)
	{
		speciesName = newSpeciesName;
	}
	
	/**
	 * set the region
	 * 
	 * @param newRegion The new region
	 */
	public void setRegion(String newRegion)
	{
		region = newRegion;
	}
	
	/**
	 * set the length of the leaves
	 * 
	 * @param newLeavesLength The new length of the leaves
	 */
	public void setLeavesLength(double newLeavesLength)
	{
		leavesLength = newLeavesLength;
		
		//if the leaves length has changed, the leaf area will need updated
		calculateLeafArea();
	}
	
	/**
	 * set the width of the leaves
	 * 
	 * @param newLeavesWidth The new width of the leaves
	 */
	public void setLeavesWidth(double newLeavesWidth)
	{
		leavesWidth = newLeavesWidth;
		
		//if the leaves width has changed, the leaf area will need updated
		calculateLeafArea();
	}
	
	/**
	 * calculate the area of the leaf based off of length and width
	 * leaf area = length * width
	 */
	private void calculateLeafArea()
	{
		leafArea = leavesLength * leavesWidth;
		
		//if the leaf area has changed, evaporation rate may need updated
		calculateEvaporationRate();
	}
	
	/**
	 * estimate evaporation rate per day (mm) based off leaf area
	 */
	private void calculateEvaporationRate()
	{
		if(leafArea < 60)
		{
			evaporationRate = 2.1;
		}
		else if((leafArea >= 60) && (leafArea < 180))
		{
			evaporationRate = 4.3;
		}
		else if((leafArea >= 180) && (leafArea < 3000))
		{
			evaporationRate = 7.7;
		}
		else if((leafArea >= 3000) && (leafArea <= 8000))
		{
			evaporationRate = 14.3;
		}
		else
		{
			evaporationRate = 24.5;
		}
		
	}
	
	//constructors
	
	/**
	 * constructor to initialise a plant, setting fields to default values
	 */
	public PlantSpecies()
	{
		speciesName = "";
		region = "";
		leavesLength = 0;
		leavesWidth = 0;
	}
	
	/**
	 * constructor to initialise a plant, setting fields to given values
	 * 
	 * @param newSpeciesName Name of the species (scientific)
	 * @param newRegion Region the plant is from
	 * @param newLeavesLength Length of the leaves
	 * @param newLeavesWidth Width of the leaves
	 */
	public PlantSpecies(String newSpeciesName, String newRegion, double newLeavesLength, double newLeavesWidth)
	{
		speciesName = newSpeciesName;
		region = newRegion;
		leavesLength = newLeavesLength;
		leavesWidth = newLeavesWidth;
	}
	
	
	
}
