package species;

//import java.util.regex.Matcher;
//import java.util.regex.Pattern;

import java.util.ArrayList;

/**
 * class containing various algorithms that could clutter the plant species database class
 * only necessary methods are public, and all are static
 * 
 * @author J. Finnon
 * @version 1.0
 */
public class Algorithms
{
	/* ATTEMPTED WILDCARD SEARCH
	
	public static ArrayList<Integer> linearSearchSpeciesName(String target, ArrayList<PlantSpecies> allPlants)
	{
		boolean matchFound;
		ArrayList<Integer> indexFound = new ArrayList<Integer>();
		
		for (int i = 0; i < allPlants.size(); i++)
		{
			matchFound = false;
			matchFound = wildCardSearch(target, allPlants.get(i).getSpeciesName());
			
			if (matchFound)
			{
				indexFound.add(i);
			}
		}
		
		return indexFound;
	}
	
	
	private static boolean wildCardSearch(String target, String check)
	{
		target.replace("?", ".");
		target.replace("*", ".+");
		
		Pattern targetRegex = Pattern.compile(target, Pattern.CASE_INSENSITIVE);
		
		Matcher matcher = targetRegex.matcher(check);
		
		boolean matchFound = matcher.find();
		
		return matchFound;
	}
	
 	*/
	
	/**
	 * method to search for species name entered by user
	 * 
	 * @param target String containing target species name
	 * @param allPlants Arraylist of database
	 * @return the index where it was found
	 */
	public static ArrayList<Integer> linearSearchSpeciesName(String target, ArrayList<PlantSpecies> allPlants)
	{
		boolean matchFound;
		//although not necessary, arraylist is used to allow for reuse of code at other point
		ArrayList<Integer> indexFound = new ArrayList<Integer>();
		
		//linear search for target
		for (int i = 0; i < allPlants.size(); i++)
		{
			matchFound = false;
			matchFound = compare(target, allPlants.get(i).getSpeciesName());
			
			if (matchFound)
			{
				indexFound.add(i);
			}
		}
		
		return indexFound;
	}
	
	/**
	 * @param target String containing target region
	 * @param allPlants Arraylist of database
	 * @return the indices of all instances of target region
	 */
	public static ArrayList<Integer> linearSearchRegion(String target, ArrayList<PlantSpecies> allPlants)
	{
		boolean matchFound;
		ArrayList<Integer> indexFound = new ArrayList<Integer>();
		
		//linear search for target
		for (int i = 0; i < allPlants.size(); i++)
		{
			matchFound = false;
			matchFound = compare(target, allPlants.get(i).getRegion());
			
			if (matchFound)
			{
				indexFound.add(i);
			}
		}
		
		return indexFound;
	}
	
	/**
	 * method to check if two strings are equal
	 * 
	 * @param strOne
	 * @param strTwo
	 * @return true or false depending on outcome
	 */
	private static boolean compare(String strOne, String strTwo)
	{
		if (strOne.equals(strTwo))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
}
