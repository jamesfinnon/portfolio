﻿Imports System.Data.SqlClient
Imports System.DirectoryServices.ActiveDirectory

Public Class Form1

    'this creates the record which will be used later to create the array and list of records
    Private Structure Product

        Dim barcode As String
        Dim producer As String
        Dim price As Double
        Dim shelfNo As Integer
        Dim position As String

    End Structure

    'this creates the list and array of records respectively
    'a list is easier to modify and add new entries to, as its size is variable
    'the array is easier to sort and rearrange, as it has a set number of entries
    Dim allProducts As New List(Of Product)
    Dim allProductsArray() As Product

    'the sorted variable will be changed depending on whether the array and list have been sorted
    Dim sorted As Boolean = False

    'this creates the connection for the integrated database
    'the connectionString stores the information used to make the connection
    'the SqlConnection is what used to interact with the database when needed
    Dim connectionString As String = "Server=DESKTOP-U828LM1\DIGITALSTOREROOM; Database=Storeroom; Integrated Security=True;"
    Dim connection As New SqlConnection(connectionString)

    'creates the 2d array "storeroom," which will store the layout of the storeroom
    Dim storeroom(12, 2) As String

    'sub procedure to load or refresh the storeroom layout displays
    Private Sub cmdLoadStoreroom_Click(sender As Object, e As EventArgs) Handles cmdLoadStoreroom.Click

        'clears all the items in the storeroom layout
        lstDisplayTopRow.Items.Clear()
        lstDisplayMiddleRow.Items.Clear()
        lstDisplayBottomRow.Items.Clear()

        'clears the storeroom array
        For loops = 0 To 12
            For looper = 0 To 2

                storeroom(loops, looper) = ""

            Next
        Next

        'calls the sub procedure to load the storeroom layout from a csv file
        getStoreroomLayout(storeroom)

        'outputs the storeroom array in a table-like format
        For loops = 0 To 12

            lstDisplayTopRow.Items.Add(storeroom(loops, 0))
            lstDisplayMiddleRow.Items.Add(storeroom(loops, 1))
            lstDisplayBottomRow.Items.Add(storeroom(loops, 2))

        Next

    End Sub

    'sub routine to get the data from a file
    Private Sub getStoreroomLayout(ByRef array1(,) As String)

        'opens the file to store data in 2d array 
        FileOpen(1, "Storeroom.csv", OpenMode.Input)

        'loops from 0 to number of entries in array
        For loops = 0 To 12
            For looper = 0 To 2

                'inputs the data to the corresponding entry
                Input(1, array1(loops, looper))

            Next
        Next

        'closes the file
        FileClose()

    End Sub

    'sub procedure to find product type in 2d array
    Private Sub cmdSearchProductType_Click(sender As Object, e As EventArgs) Handles cmdSearchProductType.Click

        'defines the positions to be later found
        Dim shelfNo As Integer
        Dim row As String
        row = ""

        'input validation
        If productType.Text = "" Then

            MsgBox("Error. Field cannot be left empty")

        Else

            'calls the linear search sub procedure - array is not sorted so cannot be searched using a binary search
            linearSearch2D(storeroom, productType.Text, shelfNo, row)

            'resets the input box
            productType.Text = ""

            'resets the output boxes
            lstDisplayShelfNoType.Items.Clear()
            lstDisplayRow.Items.Clear()

            'outputs the position
            lstDisplayShelfNoType.Items.Add(shelfNo)
            lstDisplayRow.Items.Add(row)

        End If

    End Sub

    'linear search for a 2D array
    Private Sub linearSearch2D(ByVal list(,) As String, ByVal target As String, ByRef shelfNo As Integer, ByRef row As String)

        'gets the number of items in the first dimension of the array
        Dim numItemsX As Integer
        numItemsX = list.GetLength(0) - 1

        'gets the number of items in the second dimension of the array
        Dim numItemsY As Integer
        numItemsY = list.GetLength(1) - 1

        'boolean value to check whether item has been found
        Dim found As Boolean
        found = False

        'loops through all the items in the 2d array, one by one
        For loops = 0 To numItemsX
            For looper = 0 To numItemsY

                'checks if current item is the target item
                If list(loops, looper) = target Then

                    'if found, sets the shelf number and row to the corresponding locations
                    shelfNo = loops

                    If looper = 0 Then

                        row = "Top Row"

                    ElseIf looper = 1 Then

                        row = "Middle Row"

                    Else

                        row = "Bottom Row"

                    End If

                    'sets found to true, and exits the sub routine
                    found = True
                    Exit Sub

                End If

            Next

        Next

        'if not found, tell user
        If found = False Then

            MsgBox("Product type not found.")

        End If



    End Sub

    'sub procedure to open database connection
    'procedure will also call products to be read from database
    Private Sub cmdConnect_Click(sender As Object, e As EventArgs) Handles cmdConnect.Click

        'the Try statement will attempt to open a connection to the database
        Try
            'if the connection is closed, attempt to open
            If connection.State = ConnectionState.Closed Then
                connection.Open()
                'if successful, display message
                MessageBox.Show("Connection Successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)

                'call the ReadProducts sub procedure
                ReadProducts()

                lstDisplayStatus.Items.Clear()
                lstDisplayStatus.Items.Add("Connected")

                'if the connection is already open, display message
            Else
                MessageBox.Show("Connection is already open!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Warning)

            End If

            'if an error occurs, display error message
        Catch ex As Exception
            MessageBox.Show("Connection Failed: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

        End Try

    End Sub

    'sub procedure to close connection
    Private Sub cmdDisconnect_Click(sender As Object, e As EventArgs) Handles cmdDisconnect.Click

        'the Try statement will attempt to close the connection to the database
        Try

            'if the connection is open, attempt to close
            If connection.State = ConnectionState.Open Then
                connection.Close()
                'if successful, display message
                MessageBox.Show("Connection Closed!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)

                lstDisplayStatus.Items.Clear()
                lstDisplayStatus.Items.Add("Disconnected")

                'if the connection is already closed, display message
            Else
                MessageBox.Show("Connection is already closed!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Warning)

            End If

            'if an error occurs, display error message
        Catch ex As Exception
            MessageBox.Show("Error Closing Connection: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

        End Try

    End Sub

    'sub procedure to read products from database table into list of records
    Private Sub ReadProducts()

        'creates the SQL query to select the necessary columns from the table
        Dim query As String
        query = "SELECT Barcode, Producer, Price, ShelfNo, Position FROM Products"

        'the command variable is used to refer to this SqlCommand
        'the SqlCommand uses the query, and the pre-existing connection
        Using command As New SqlCommand(query, connection)

            'the reader variable is used to refer to this SqlDataReader
            'the SqlDataReader is used to read data from the database table using the command created earlier
            Using reader As SqlDataReader = command.ExecuteReader()

                'repeat while there are still rows in the table to read
                While reader.Read()

                    'creates a temporary variable to store the product details to be added to the list
                    Dim newProduct As Product

                    'reads said details from the database table into the temporary variable
                    newProduct.barcode = reader.GetString(0)
                    newProduct.producer = reader.GetString(1)
                    newProduct.price = reader.GetDouble(2)
                    newProduct.shelfNo = reader.GetInt32(3)
                    newProduct.position = reader.GetString(4)

                    'adds the new product to the end of the list
                    allProducts.Add(newProduct)

                End While

            End Using

        End Using

    End Sub

    'binary search algorithm, tailored to the Product record structure
    Private Sub BinarySearch(ByVal list() As Product, ByVal target As String, ByRef message As String, ByRef positon As Integer)

        'initialises necessary variables
        'low is set to 0 - start of the list
        Dim low As Integer

        'high is set to the end of the list
        Dim high As Integer
        high = list.Length - 1

        'mid is defined later
        Dim mid As Integer

        'found is initially false
        Dim found As Boolean
        found = False

        'while not found, and not every item has been checked
        While Not found And low <= high

            'set the midpoint to (low + high) / 2
            mid = (low + high) / 2

            'of the target is equal to the middle entry, end search, change necessary values
            If target = list(mid).barcode Then

                message = ""
                positon = mid
                found = True

                'if the number portion of the target barcode is greater than the number portion of the middle barcode
            ElseIf CLng(target) > CLng(list(mid).barcode) Then

                'set the lowpoint to the midpoint + 1
                low = mid + 1

                'otherwise
            Else

                'set the highpoint to the midpoint - 1
                high = mid - 1

            End If

        End While

        'if not found, define error message
        If found = False Then

            message = "Product not found."

        End If

    End Sub

    'insertion sort algorithm, tailored to the Product record structure
    'this will sort the array of records by their barcode number
    Private Sub InsertionSort(ByRef list() As Product)

        'if the list is already sorted then exit the sub
        'improves efficiency
        If sorted Then

            Exit Sub

        End If

        'holds the number of items in the array as a variable
        Dim numItems As Integer
        numItems = list.Length - 1

        'the value variable has to be Long (a 64 bit integer) as a 32 bit standard integer is not big enough for the typical 12 digit barcode
        Dim value As Long

        'index to be used in sorting algorithm
        Dim index As Integer

        'temporary prooduct to be used in sorting algorithm
        Dim temp As Product

        'loops from 1 to number of items in the array
        For loops = 1 To (numItems)

            'sets the index to the current number of loops - 1
            index = loops - 1

            'sets the value as the number portion of the barcode
            'barcodes can start with 0, so must be stored as a string in the database table and the array of records
            value = CLng(list(loops).barcode)

            'sets the temporary product to the item in the array at the current number of loops
            temp = list(loops)

            'loops while the index is greater than or equal to 0, and the current 2 items are in the wrong order
            'the AndAlso comparator will check the boolean on the left, and then the right, instead of both simultaneously
            'this is essential, as when the index is less than 0, the program is checking for list(-1).barcode
            'this avoids a "System.IndexOutOfRangeException error code"
            While index >= 0 AndAlso value < CLng(list(index).barcode)

                'sets list(index + 1) to list(index)
                list(index + 1) = list(index)

                'sets index to itself - 1
                index = index - 1

            End While

            'sets list(index + 1) to the temporary product
            list(index + 1) = temp

        Next

        'changes sorted to true, as the list is now in order of barcode
        sorted = True

    End Sub

    'sub procedure to add new product to the list
    Private Sub cmdAddNewProduct_Click(sender As Object, e As EventArgs) Handles cmdAddNewProduct.Click

        'input validation
        If newProductBarcode.Text = "" Or newProductProducer.Text = "" Or newProductPosition.Text = "" Then

            MsgBox("Error. No field can be left empty")

        ElseIf Len(newProductBarcode.Text) > 50 Then

            MsgBox("Error. The length of the barcode cannot be greater than 50 digits.")

        ElseIf Not IsNumeric(newProductBarcode.Text) Then

            MsgBox("Error. The barcode entered is not a numerical value.")

        ElseIf Len(newProductProducer.Text) > 50 Then

            MsgBox("Error. The length of the producer's name cannot be greater than 50 characters.")

        ElseIf Not IsNumeric(newProductPrice.Text) Then

            MsgBox("Error. The price entered is not a numerical value.")

        ElseIf Not IsNumeric(newProductShelfNo.Text) Then

            MsgBox("Error. The shelf number entered is not a numerical value.")

        ElseIf Int(newProductShelfNo.Text) > 12 Or Int(newProductShelfNo.Text) < 0 Then

            MsgBox("Error. The shelf number must be between 0 and 12 inclusive.")

        ElseIf Len(newProductPosition.Text) > 50 Then

            MsgBox("Error. The length of the position cannot be greater than 50 characters.")

            'check to ensure connection is open
        ElseIf connection.State = ConnectionState.Closed Then

            MsgBox("Error. Connection to database must be established beforehand.")

        Else

            'binary search to ensure barcode is not already in database

            'sets the allProductsArray to the array version of the allProductsList
            allProductsArray = allProducts.ToArray

            'if array is not sorted then sort
            If Not sorted Then

                InsertionSort(allProductsArray)

            End If

            'creates the values necessary to be passed into the binary search
            Dim position As Integer
            Dim message As String
            message = ""

            'calls the binary search sub procedure, using the users input as the target
            BinarySearch(allProductsArray, newProductBarcode.Text, message, position)

            'if found, output results of search
            If message = "" Then

                MsgBox("Error. Product is already in database.")

                'if not found, continue adding to database
            Else

                'creates a temporary new product to be added to the end of the list
                Dim newProduct As Product

                newProduct.barcode = newProductBarcode.Text
                newProduct.producer = newProductProducer.Text
                newProduct.price = newProductPrice.Text
                newProduct.shelfNo = newProductShelfNo.Text
                newProduct.position = newProductPosition.Text

                'adds new product to the end of the list
                allProducts.Add(newProduct)

                'sets the allProductsArray to the array version of the allProducts list
                allProductsArray = allProducts.ToArray

                'sets sorted to false
                'new product has been added to the end so the array is no longer in order
                sorted = False

                'calls for the insertion sort of the array
                InsertionSort(allProductsArray)

                'updates the database with the new order and entry
                UpdateDatabase()

                'resets the input boxes
                newProductBarcode.Text = ""
                newProductProducer.Text = ""
                newProductPrice.Text = ""
                newProductShelfNo.Text = ""
                newProductPosition.Text = ""

                'sends completion message
                MsgBox("Product successfully added to database!")

            End If

        End If

    End Sub

    'sub procedure to update the database
    Private Sub UpdateDatabase()

        'if the array has not been sorted then sort the array
        If Not sorted Then

            allProductsArray = allProducts.ToArray
            InsertionSort(allProductsArray)

        End If

        'defines the SQL command to clear the database table, ready to be repopulated with new values
        Dim clearTable As String
        clearTable = "DELETE FROM Products"

        'executes the delete command
        Using deleteCommand As New SqlCommand(clearTable, connection)

            deleteCommand.ExecuteNonQuery()

        End Using

        'defines the SQL command to add the products back into the database
        Dim insertQuery As String
        insertQuery = "INSERT INTO Products (Barcode, Producer, Price, ShelfNo, Position) VALUES (@barcode, @producer, @price, @shelfNo, @position)"

        'loops through all entries
        For loops = 0 To (allProductsArray.Length - 1)

            'creates the SQL command to add new entries to the database
            Using insertCommand As New SqlCommand(insertQuery, connection)

                'parameters to be added to the database
                'used to increase readability
                insertCommand.Parameters.AddWithValue("@barcode", allProductsArray(loops).barcode)
                insertCommand.Parameters.AddWithValue("@producer", allProductsArray(loops).producer)
                insertCommand.Parameters.AddWithValue("@price", allProductsArray(loops).price)
                insertCommand.Parameters.AddWithValue("@shelfNo", allProductsArray(loops).shelfNo)
                insertCommand.Parameters.AddWithValue("@position", allProductsArray(loops).position)

                'executes command
                insertCommand.ExecuteNonQuery()

            End Using

        Next

    End Sub

    'sub procedure to delete specified entry in database
    Private Sub cmdDelete_Click(sender As Object, e As EventArgs) Handles cmdDelete.Click

        'input validation
        If deleteProductBarcode.Text = "" Then

            MsgBox("Error. Field cannot be left empty")

        ElseIf Len(deleteProductBarcode.Text) > 50 Then

            MsgBox("Error. The length of the barcode cannot be greater than 50 digits.")

        ElseIf Not IsNumeric(deleteProductBarcode.Text) Then

            MsgBox("Error. The barcode entered is not a numerical value.")

            'check to ensure connection is open
        ElseIf connection.State = ConnectionState.Closed Then

            MsgBox("Error. Connection to database must be established beforehand.")

        Else

            'calls the sub procedure to delete the specified product
            DeleteProduct(deleteProductBarcode.Text)

            'resets the input box
            deleteProductBarcode.Text = ""

        End If

    End Sub

    'sub procedure to delete product from database
    Private Sub DeleteProduct(ByVal barcode As String)

        'defines the SQL command to delete the the entry containing the specified barcode
        Dim deleteCommand As String
        deleteCommand = "DELETE FROM Products WHERE Barcode = @barcode"

        'attempts to execute SQL command to delete entry containing specified barcode
        Try
            Using command As New SqlCommand(deleteCommand, connection)

                command.Parameters.AddWithValue("@barcode", barcode)

                'sets found initially false
                Dim found As Boolean
                found = False

                'if successfully deleted, found becomes true
                found = command.ExecuteNonQuery()

                'if found, display message
                If found Then

                    MsgBox("Product successfully deleted.")

                    'if not found, display message
                Else

                    MsgBox("Product not found.")

                End If

            End Using

            'if command fails, display error message
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)

        End Try

        'resets the products list, and calls for it to be repopulated from the database
        allProducts.Clear()
        ReadProducts()

    End Sub

    'sub procedure to search for a product
    Private Sub cmdSearchProduct_Click(sender As Object, e As EventArgs) Handles cmdSearchProduct.Click

        'input validation
        If searchProduct.Text = "" Then

            MsgBox("Error. Field cannot be left empty")

        ElseIf Len(searchProduct.Text) > 50 Then

            MsgBox("Error. The length of the barcode cannot be greater than 50 digits.")

        ElseIf Not IsNumeric(searchProduct.Text) Then

            MsgBox("Error. The barcode entered is not a numerical value.")

            'check to ensure connection is open
            'if not, display error message
        ElseIf connection.State = ConnectionState.Closed Then

            MsgBox("Error. Connection to database must be established beforehand.")

        Else

            'sets the allProductsArray to the array version of the allProductsList
            allProductsArray = allProducts.ToArray

            'if array is not sorted then sort
            If Not sorted Then

                InsertionSort(allProductsArray)

            End If

            'creates the values necessary to be passed into the binary search
            Dim position As Integer
            Dim message As String
            message = ""

            'calls the binary search sub procedure, using the users input as the target
            BinarySearch(allProductsArray, searchProduct.Text, message, position)

            'resets the input and output boxes
            searchProduct.Text = ""
            lstDisplayProducer.Items.Clear()
            lstDisplayPrice.Items.Clear()
            lstDisplayShelfNo.Items.Clear()
            lstDisplayPosition.Items.Clear()

            'if found, output results of search
            If message = "" Then

                lstDisplayProducer.Items.Add(allProductsArray(position).producer)
                lstDisplayPrice.Items.Add(allProductsArray(position).price)
                lstDisplayShelfNo.Items.Add(allProductsArray(position).shelfNo)
                lstDisplayPosition.Items.Add(allProductsArray(position).position)

                'if not found, output not found message
            Else

                MsgBox(message)

            End If

        End If

    End Sub

End Class
