﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        lstDisplayMiddleRow = New ListBox()
        cmdConnect = New Button()
        cmdDisconnect = New Button()
        newProductBarcode = New TextBox()
        Label1 = New Label()
        Label = New Label()
        newProductProducer = New TextBox()
        Label2 = New Label()
        Label3 = New Label()
        newProductPrice = New TextBox()
        Label4 = New Label()
        newProductShelfNo = New TextBox()
        Label5 = New Label()
        newProductPosition = New TextBox()
        cmdAddNewProduct = New Button()
        Label6 = New Label()
        Label7 = New Label()
        searchProduct = New TextBox()
        cmdSearchProduct = New Button()
        Label8 = New Label()
        Label9 = New Label()
        Label10 = New Label()
        Label11 = New Label()
        lstDisplayPrice = New ListBox()
        lstDisplayShelfNo = New ListBox()
        lstDisplayPosition = New ListBox()
        lstDisplayProducer = New ListBox()
        Label12 = New Label()
        Label13 = New Label()
        deleteProductBarcode = New TextBox()
        cmdDelete = New Button()
        Label14 = New Label()
        Label15 = New Label()
        Label16 = New Label()
        Label17 = New Label()
        Label18 = New Label()
        lstDisplayTopRow = New ListBox()
        lstDisplayBottomRow = New ListBox()
        Label19 = New Label()
        Label20 = New Label()
        Label21 = New Label()
        Label22 = New Label()
        Label23 = New Label()
        Label24 = New Label()
        Label25 = New Label()
        Label26 = New Label()
        Label27 = New Label()
        Label28 = New Label()
        Label29 = New Label()
        Label30 = New Label()
        cmdLoadStoreroom = New Button()
        Label31 = New Label()
        cmdSearchProductType = New Button()
        Label32 = New Label()
        productType = New TextBox()
        Label33 = New Label()
        lstDisplayShelfNoType = New ListBox()
        Label34 = New Label()
        lstDisplayRow = New ListBox()
        Label35 = New Label()
        lstDisplayStatus = New ListBox()
        Label36 = New Label()
        SuspendLayout()
        ' 
        ' lstDisplayMiddleRow
        ' 
        lstDisplayMiddleRow.FormattingEnabled = True
        lstDisplayMiddleRow.ItemHeight = 25
        lstDisplayMiddleRow.Location = New Point(281, 83)
        lstDisplayMiddleRow.Name = "lstDisplayMiddleRow"
        lstDisplayMiddleRow.Size = New Size(188, 329)
        lstDisplayMiddleRow.TabIndex = 0
        ' 
        ' cmdConnect
        ' 
        cmdConnect.Location = New Point(1934, 133)
        cmdConnect.Name = "cmdConnect"
        cmdConnect.Size = New Size(344, 159)
        cmdConnect.TabIndex = 1
        cmdConnect.Text = "Connect to Database"
        cmdConnect.UseVisualStyleBackColor = True
        ' 
        ' cmdDisconnect
        ' 
        cmdDisconnect.Location = New Point(1934, 332)
        cmdDisconnect.Name = "cmdDisconnect"
        cmdDisconnect.Size = New Size(344, 159)
        cmdDisconnect.TabIndex = 2
        cmdDisconnect.Text = "Disconnect From Database"
        cmdDisconnect.UseVisualStyleBackColor = True
        ' 
        ' newProductBarcode
        ' 
        newProductBarcode.Location = New Point(1369, 87)
        newProductBarcode.Name = "newProductBarcode"
        newProductBarcode.Size = New Size(223, 31)
        newProductBarcode.TabIndex = 4
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point)
        Label1.Location = New Point(1369, 12)
        Label1.Name = "Label1"
        Label1.Size = New Size(223, 32)
        Label1.TabIndex = 5
        Label1.Text = "Add A New Product"
        ' 
        ' Label
        ' 
        Label.AutoSize = True
        Label.Location = New Point(1369, 59)
        Label.Name = "Label"
        Label.Size = New Size(76, 25)
        Label.TabIndex = 6
        Label.Text = "Barcode"
        ' 
        ' newProductProducer
        ' 
        newProductProducer.Location = New Point(1369, 149)
        newProductProducer.Name = "newProductProducer"
        newProductProducer.Size = New Size(223, 31)
        newProductProducer.TabIndex = 7
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(1369, 121)
        Label2.Name = "Label2"
        Label2.Size = New Size(83, 25)
        Label2.TabIndex = 8
        Label2.Text = "Producer"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(1369, 183)
        Label3.Name = "Label3"
        Label3.Size = New Size(49, 25)
        Label3.TabIndex = 9
        Label3.Text = "Price"
        ' 
        ' newProductPrice
        ' 
        newProductPrice.Location = New Point(1369, 211)
        newProductPrice.Name = "newProductPrice"
        newProductPrice.Size = New Size(223, 31)
        newProductPrice.TabIndex = 10
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Location = New Point(1369, 245)
        Label4.Name = "Label4"
        Label4.Size = New Size(245, 25)
        Label4.TabIndex = 11
        Label4.Text = "Shelf Number - 0 Through 12" & vbCrLf
        ' 
        ' newProductShelfNo
        ' 
        newProductShelfNo.Location = New Point(1369, 273)
        newProductShelfNo.Name = "newProductShelfNo"
        newProductShelfNo.Size = New Size(223, 31)
        newProductShelfNo.TabIndex = 12
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Location = New Point(1369, 307)
        Label5.Name = "Label5"
        Label5.Size = New Size(145, 25)
        Label5.TabIndex = 13
        Label5.Text = "Position on Shelf"
        ' 
        ' newProductPosition
        ' 
        newProductPosition.Location = New Point(1369, 335)
        newProductPosition.Name = "newProductPosition"
        newProductPosition.Size = New Size(223, 31)
        newProductPosition.TabIndex = 14
        ' 
        ' cmdAddNewProduct
        ' 
        cmdAddNewProduct.Location = New Point(1369, 372)
        cmdAddNewProduct.Name = "cmdAddNewProduct"
        cmdAddNewProduct.Size = New Size(223, 121)
        cmdAddNewProduct.TabIndex = 15
        cmdAddNewProduct.Text = "Add Product"
        cmdAddNewProduct.UseVisualStyleBackColor = True
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point)
        Label6.Location = New Point(1078, 9)
        Label6.Name = "Label6"
        Label6.Size = New Size(237, 32)
        Label6.TabIndex = 16
        Label6.Text = "Search For A Product"
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Location = New Point(1078, 56)
        Label7.Name = "Label7"
        Label7.Size = New Size(76, 25)
        Label7.TabIndex = 17
        Label7.Text = "Barcode"
        ' 
        ' searchProduct
        ' 
        searchProduct.Location = New Point(1078, 83)
        searchProduct.Name = "searchProduct"
        searchProduct.Size = New Size(223, 31)
        searchProduct.TabIndex = 18
        ' 
        ' cmdSearchProduct
        ' 
        cmdSearchProduct.Location = New Point(1078, 120)
        cmdSearchProduct.Name = "cmdSearchProduct"
        cmdSearchProduct.Size = New Size(223, 121)
        cmdSearchProduct.TabIndex = 19
        cmdSearchProduct.Text = "Search"
        cmdSearchProduct.UseVisualStyleBackColor = True
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Location = New Point(1078, 434)
        Label8.Name = "Label8"
        Label8.Size = New Size(145, 25)
        Label8.TabIndex = 26
        Label8.Text = "Position on Shelf"
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Location = New Point(1078, 372)
        Label9.Name = "Label9"
        Label9.Size = New Size(121, 25)
        Label9.TabIndex = 24
        Label9.Text = "Shelf Number"
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.Location = New Point(1078, 310)
        Label10.Name = "Label10"
        Label10.Size = New Size(49, 25)
        Label10.TabIndex = 22
        Label10.Text = "Price"
        ' 
        ' Label11
        ' 
        Label11.AutoSize = True
        Label11.Location = New Point(1078, 248)
        Label11.Name = "Label11"
        Label11.Size = New Size(83, 25)
        Label11.TabIndex = 21
        Label11.Text = "Producer"
        ' 
        ' lstDisplayPrice
        ' 
        lstDisplayPrice.FormattingEnabled = True
        lstDisplayPrice.ItemHeight = 25
        lstDisplayPrice.Location = New Point(1078, 338)
        lstDisplayPrice.Name = "lstDisplayPrice"
        lstDisplayPrice.Size = New Size(223, 29)
        lstDisplayPrice.TabIndex = 27
        ' 
        ' lstDisplayShelfNo
        ' 
        lstDisplayShelfNo.FormattingEnabled = True
        lstDisplayShelfNo.ItemHeight = 25
        lstDisplayShelfNo.Location = New Point(1078, 402)
        lstDisplayShelfNo.Name = "lstDisplayShelfNo"
        lstDisplayShelfNo.Size = New Size(223, 29)
        lstDisplayShelfNo.TabIndex = 28
        ' 
        ' lstDisplayPosition
        ' 
        lstDisplayPosition.FormattingEnabled = True
        lstDisplayPosition.ItemHeight = 25
        lstDisplayPosition.Location = New Point(1078, 462)
        lstDisplayPosition.Name = "lstDisplayPosition"
        lstDisplayPosition.Size = New Size(223, 29)
        lstDisplayPosition.TabIndex = 29
        ' 
        ' lstDisplayProducer
        ' 
        lstDisplayProducer.FormattingEnabled = True
        lstDisplayProducer.ItemHeight = 25
        lstDisplayProducer.Location = New Point(1078, 278)
        lstDisplayProducer.Name = "lstDisplayProducer"
        lstDisplayProducer.Size = New Size(223, 29)
        lstDisplayProducer.TabIndex = 30
        ' 
        ' Label12
        ' 
        Label12.AutoSize = True
        Label12.Font = New Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point)
        Label12.Location = New Point(1655, 8)
        Label12.Name = "Label12"
        Label12.Size = New Size(173, 32)
        Label12.TabIndex = 31
        Label12.Text = "Delete Product"
        ' 
        ' Label13
        ' 
        Label13.AutoSize = True
        Label13.Location = New Point(1655, 56)
        Label13.Name = "Label13"
        Label13.Size = New Size(76, 25)
        Label13.TabIndex = 32
        Label13.Text = "Barcode"
        ' 
        ' deleteProductBarcode
        ' 
        deleteProductBarcode.Location = New Point(1655, 83)
        deleteProductBarcode.Name = "deleteProductBarcode"
        deleteProductBarcode.Size = New Size(223, 31)
        deleteProductBarcode.TabIndex = 33
        ' 
        ' cmdDelete
        ' 
        cmdDelete.Location = New Point(1655, 120)
        cmdDelete.Name = "cmdDelete"
        cmdDelete.Size = New Size(223, 121)
        cmdDelete.TabIndex = 34
        cmdDelete.Text = "Delete"
        cmdDelete.UseVisualStyleBackColor = True
        ' 
        ' Label14
        ' 
        Label14.AutoSize = True
        Label14.Font = New Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point)
        Label14.Location = New Point(15, 8)
        Label14.Name = "Label14"
        Label14.Size = New Size(204, 32)
        Label14.TabIndex = 35
        Label14.Text = "Storeroom Layout"
        ' 
        ' Label15
        ' 
        Label15.AutoSize = True
        Label15.Location = New Point(15, 83)
        Label15.Name = "Label15"
        Label15.Size = New Size(66, 25)
        Label15.TabIndex = 36
        Label15.Text = "Shelf 0"
        ' 
        ' Label16
        ' 
        Label16.AutoSize = True
        Label16.Location = New Point(87, 55)
        Label16.Name = "Label16"
        Label16.Size = New Size(80, 25)
        Label16.TabIndex = 39
        Label16.Text = "Top Row"
        ' 
        ' Label17
        ' 
        Label17.AutoSize = True
        Label17.Location = New Point(281, 55)
        Label17.Name = "Label17"
        Label17.Size = New Size(106, 25)
        Label17.TabIndex = 40
        Label17.Text = "Middle Row"
        ' 
        ' Label18
        ' 
        Label18.AutoSize = True
        Label18.Location = New Point(475, 55)
        Label18.Name = "Label18"
        Label18.Size = New Size(111, 25)
        Label18.TabIndex = 41
        Label18.Text = "Bottom Row"
        ' 
        ' lstDisplayTopRow
        ' 
        lstDisplayTopRow.FormattingEnabled = True
        lstDisplayTopRow.ItemHeight = 25
        lstDisplayTopRow.Location = New Point(87, 83)
        lstDisplayTopRow.Name = "lstDisplayTopRow"
        lstDisplayTopRow.Size = New Size(188, 329)
        lstDisplayTopRow.TabIndex = 48
        ' 
        ' lstDisplayBottomRow
        ' 
        lstDisplayBottomRow.FormattingEnabled = True
        lstDisplayBottomRow.ItemHeight = 25
        lstDisplayBottomRow.Location = New Point(475, 83)
        lstDisplayBottomRow.Name = "lstDisplayBottomRow"
        lstDisplayBottomRow.Size = New Size(188, 329)
        lstDisplayBottomRow.TabIndex = 53
        ' 
        ' Label19
        ' 
        Label19.AutoSize = True
        Label19.Location = New Point(5, 386)
        Label19.Name = "Label19"
        Label19.Size = New Size(76, 25)
        Label19.TabIndex = 54
        Label19.Text = "Shelf 12"
        ' 
        ' Label20
        ' 
        Label20.AutoSize = True
        Label20.Location = New Point(5, 361)
        Label20.Name = "Label20"
        Label20.Size = New Size(76, 25)
        Label20.TabIndex = 55
        Label20.Text = "Shelf 11"
        ' 
        ' Label21
        ' 
        Label21.AutoSize = True
        Label21.Location = New Point(5, 336)
        Label21.Name = "Label21"
        Label21.Size = New Size(76, 25)
        Label21.TabIndex = 56
        Label21.Text = "Shelf 10"
        ' 
        ' Label22
        ' 
        Label22.AutoSize = True
        Label22.Location = New Point(15, 311)
        Label22.Name = "Label22"
        Label22.Size = New Size(66, 25)
        Label22.TabIndex = 57
        Label22.Text = "Shelf 9"
        ' 
        ' Label23
        ' 
        Label23.AutoSize = True
        Label23.Location = New Point(15, 286)
        Label23.Name = "Label23"
        Label23.Size = New Size(66, 25)
        Label23.TabIndex = 58
        Label23.Text = "Shelf 8"
        ' 
        ' Label24
        ' 
        Label24.AutoSize = True
        Label24.Location = New Point(15, 261)
        Label24.Name = "Label24"
        Label24.Size = New Size(66, 25)
        Label24.TabIndex = 59
        Label24.Text = "Shelf 7"
        ' 
        ' Label25
        ' 
        Label25.AutoSize = True
        Label25.Location = New Point(15, 236)
        Label25.Name = "Label25"
        Label25.Size = New Size(66, 25)
        Label25.TabIndex = 60
        Label25.Text = "Shelf 6"
        ' 
        ' Label26
        ' 
        Label26.AutoSize = True
        Label26.Location = New Point(15, 211)
        Label26.Name = "Label26"
        Label26.Size = New Size(66, 25)
        Label26.TabIndex = 61
        Label26.Text = "Shelf 5"
        ' 
        ' Label27
        ' 
        Label27.AutoSize = True
        Label27.Location = New Point(15, 183)
        Label27.Name = "Label27"
        Label27.Size = New Size(66, 25)
        Label27.TabIndex = 62
        Label27.Text = "Shelf 4"
        ' 
        ' Label28
        ' 
        Label28.AutoSize = True
        Label28.Location = New Point(15, 158)
        Label28.Name = "Label28"
        Label28.Size = New Size(66, 25)
        Label28.TabIndex = 63
        Label28.Text = "Shelf 3"
        ' 
        ' Label29
        ' 
        Label29.AutoSize = True
        Label29.Location = New Point(15, 133)
        Label29.Name = "Label29"
        Label29.Size = New Size(66, 25)
        Label29.TabIndex = 64
        Label29.Text = "Shelf 2"
        ' 
        ' Label30
        ' 
        Label30.AutoSize = True
        Label30.Location = New Point(15, 108)
        Label30.Name = "Label30"
        Label30.Size = New Size(66, 25)
        Label30.TabIndex = 65
        Label30.Text = "Shelf 1"
        ' 
        ' cmdLoadStoreroom
        ' 
        cmdLoadStoreroom.Location = New Point(87, 418)
        cmdLoadStoreroom.Name = "cmdLoadStoreroom"
        cmdLoadStoreroom.Size = New Size(188, 75)
        cmdLoadStoreroom.TabIndex = 66
        cmdLoadStoreroom.Text = "Load/Refresh Storeroom"
        cmdLoadStoreroom.UseVisualStyleBackColor = True
        ' 
        ' Label31
        ' 
        Label31.AutoSize = True
        Label31.Font = New Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point)
        Label31.Location = New Point(746, 9)
        Label31.Name = "Label31"
        Label31.Size = New Size(295, 32)
        Label31.TabIndex = 67
        Label31.Text = "Search For A Product Type"
        ' 
        ' cmdSearchProductType
        ' 
        cmdSearchProductType.Location = New Point(746, 120)
        cmdSearchProductType.Name = "cmdSearchProductType"
        cmdSearchProductType.Size = New Size(223, 121)
        cmdSearchProductType.TabIndex = 68
        cmdSearchProductType.Text = "Search"
        cmdSearchProductType.UseVisualStyleBackColor = True
        ' 
        ' Label32
        ' 
        Label32.AutoSize = True
        Label32.Location = New Point(746, 55)
        Label32.Name = "Label32"
        Label32.Size = New Size(116, 25)
        Label32.TabIndex = 69
        Label32.Text = "Product Type"
        ' 
        ' productType
        ' 
        productType.Location = New Point(746, 83)
        productType.Name = "productType"
        productType.Size = New Size(223, 31)
        productType.TabIndex = 70
        ' 
        ' Label33
        ' 
        Label33.AutoSize = True
        Label33.Location = New Point(746, 246)
        Label33.Name = "Label33"
        Label33.Size = New Size(121, 25)
        Label33.TabIndex = 71
        Label33.Text = "Shelf Number"
        ' 
        ' lstDisplayShelfNoType
        ' 
        lstDisplayShelfNoType.FormattingEnabled = True
        lstDisplayShelfNoType.ItemHeight = 25
        lstDisplayShelfNoType.Location = New Point(746, 274)
        lstDisplayShelfNoType.Name = "lstDisplayShelfNoType"
        lstDisplayShelfNoType.Size = New Size(223, 29)
        lstDisplayShelfNoType.TabIndex = 72
        ' 
        ' Label34
        ' 
        Label34.AutoSize = True
        Label34.Location = New Point(746, 311)
        Label34.Name = "Label34"
        Label34.Size = New Size(46, 25)
        Label34.TabIndex = 73
        Label34.Text = "Row"
        ' 
        ' lstDisplayRow
        ' 
        lstDisplayRow.FormattingEnabled = True
        lstDisplayRow.ItemHeight = 25
        lstDisplayRow.Location = New Point(746, 339)
        lstDisplayRow.Name = "lstDisplayRow"
        lstDisplayRow.Size = New Size(223, 29)
        lstDisplayRow.TabIndex = 74
        ' 
        ' Label35
        ' 
        Label35.AutoSize = True
        Label35.Font = New Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point)
        Label35.Location = New Point(1934, 8)
        Label35.Name = "Label35"
        Label35.Size = New Size(242, 32)
        Label35.TabIndex = 75
        Label35.Text = "Database Connection"
        ' 
        ' lstDisplayStatus
        ' 
        lstDisplayStatus.FormattingEnabled = True
        lstDisplayStatus.ItemHeight = 25
        lstDisplayStatus.Items.AddRange(New Object() {"Disconnected"})
        lstDisplayStatus.Location = New Point(1934, 79)
        lstDisplayStatus.Name = "lstDisplayStatus"
        lstDisplayStatus.Size = New Size(223, 29)
        lstDisplayStatus.TabIndex = 76
        ' 
        ' Label36
        ' 
        Label36.AutoSize = True
        Label36.Location = New Point(1934, 55)
        Label36.Name = "Label36"
        Label36.Size = New Size(60, 25)
        Label36.TabIndex = 77
        Label36.Text = "Status"
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(10F, 25F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(2296, 1443)
        Controls.Add(Label36)
        Controls.Add(lstDisplayStatus)
        Controls.Add(Label35)
        Controls.Add(lstDisplayRow)
        Controls.Add(Label34)
        Controls.Add(lstDisplayShelfNoType)
        Controls.Add(Label33)
        Controls.Add(productType)
        Controls.Add(Label32)
        Controls.Add(cmdSearchProductType)
        Controls.Add(Label31)
        Controls.Add(cmdLoadStoreroom)
        Controls.Add(Label30)
        Controls.Add(Label29)
        Controls.Add(Label28)
        Controls.Add(Label27)
        Controls.Add(Label26)
        Controls.Add(Label25)
        Controls.Add(Label24)
        Controls.Add(Label23)
        Controls.Add(Label22)
        Controls.Add(Label21)
        Controls.Add(Label20)
        Controls.Add(Label19)
        Controls.Add(lstDisplayBottomRow)
        Controls.Add(lstDisplayTopRow)
        Controls.Add(Label18)
        Controls.Add(Label17)
        Controls.Add(Label16)
        Controls.Add(Label15)
        Controls.Add(Label14)
        Controls.Add(cmdDelete)
        Controls.Add(deleteProductBarcode)
        Controls.Add(Label13)
        Controls.Add(Label12)
        Controls.Add(lstDisplayProducer)
        Controls.Add(lstDisplayPosition)
        Controls.Add(lstDisplayShelfNo)
        Controls.Add(lstDisplayPrice)
        Controls.Add(Label8)
        Controls.Add(Label9)
        Controls.Add(Label10)
        Controls.Add(Label11)
        Controls.Add(cmdSearchProduct)
        Controls.Add(searchProduct)
        Controls.Add(Label7)
        Controls.Add(Label6)
        Controls.Add(cmdAddNewProduct)
        Controls.Add(newProductPosition)
        Controls.Add(Label5)
        Controls.Add(newProductShelfNo)
        Controls.Add(Label4)
        Controls.Add(newProductPrice)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(newProductProducer)
        Controls.Add(Label)
        Controls.Add(Label1)
        Controls.Add(newProductBarcode)
        Controls.Add(cmdDisconnect)
        Controls.Add(cmdConnect)
        Controls.Add(lstDisplayMiddleRow)
        Name = "Form1"
        Text = "Form1"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents lstDisplayMiddleRow As ListBox
    Friend WithEvents cmdConnect As Button
    Friend WithEvents cmdDisconnect As Button
    Friend WithEvents newProductBarcode As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label As Label
    Friend WithEvents newProductProducer As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents newProductPrice As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents newProductShelfNo As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents newProductPosition As TextBox
    Friend WithEvents cmdAddNewProduct As Button
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents searchProduct As TextBox
    Friend WithEvents cmdSearchProduct As Button
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents lstDisplayPrice As ListBox
    Friend WithEvents lstDisplayShelfNo As ListBox
    Friend WithEvents lstDisplayPosition As ListBox
    Friend WithEvents lstDisplayProducer As ListBox
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents deleteProductBarcode As TextBox
    Friend WithEvents cmdDelete As Button
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents lstDisplayTopRow As ListBox
    Friend WithEvents lstDisplayBottomRow As ListBox
    Friend WithEvents Label19 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents Label29 As Label
    Friend WithEvents Label30 As Label
    Friend WithEvents cmdLoadStoreroom As Button
    Friend WithEvents Label31 As Label
    Friend WithEvents cmdSearchProductType As Button
    Friend WithEvents Label32 As Label
    Friend WithEvents productType As TextBox
    Friend WithEvents Label33 As Label
    Friend WithEvents lstDisplayShelfNoType As ListBox
    Friend WithEvents Label34 As Label
    Friend WithEvents lstDisplayRow As ListBox
    Friend WithEvents Label35 As Label
    Friend WithEvents lstDisplayStatus As ListBox
    Friend WithEvents Label36 As Label
End Class
