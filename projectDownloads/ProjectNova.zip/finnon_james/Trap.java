import java.awt.Point;
import java.io.Serializable;

// class for trap types
public class Trap implements Serializable {
    String name;
    Point[] shape;
    int anchorRow;
    int anchorCol;

    enum TRAP_TYPE { SEA_MINE, BOMBFISH, KELP }
    TRAP_TYPE type;
    
    // constructor to create trap
    public Trap(String name, Point[] shape, TRAP_TYPE type) {
        this.name = name;
        this.shape = shape;
        this.type = type;
    }
}