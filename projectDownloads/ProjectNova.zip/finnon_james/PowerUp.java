import java.awt.Point;
import java.io.Serializable;

// class for powerup types
public class PowerUp implements Serializable {
	String name;
    Point[] shape;
    int anchorRow;
    int anchorCol; 
	
	enum POWERUP_TYPE { HEALTH_BOOST, EXTRA_TURN, REVEAL }
	POWERUP_TYPE type;

	public PowerUp(String name, Point[] shape, POWERUP_TYPE type) {
	    this.name = name;
	    this.shape = shape;
	    this.type = type;
	}
	 
}
