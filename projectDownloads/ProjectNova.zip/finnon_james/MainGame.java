// imports
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import java.util.ArrayList;
import java.util.Random;


// MainGame class - built off of sample gui
public class MainGame implements ActionListener 
{
	// creates 2 player objects
	Player player1 = new Player();
	Player player2 = new Player();	
	
	// ensures the game has been started before user can guess anything
	private boolean gameStarted = false;
	
	// used to flash the timer when time is running out
	private boolean flashState = false;     
	private Color defaultTimerColor = Color.WHITE;
	
	// labels for current turn and timer
	private JLabel turnLabel;
	private JLabel timerLabel;
	
	// timer and initial time left
	private Timer gameTimer;
    private int timeLeft = 10;
	
	// tracks whose turn it is
	private boolean player1Turn = true;
	
	// whether or not the user is playing against the computer
	private boolean vsComputer = false;
	
	// maximum number of traps, powerups and sinkholes
	private int maxTraps;
	private int maxPowerUps;
	private int maxSinkholes;
	
	
    // enumerated type for all colours used
    private enum GRID_COLOUR
    {
        BLANK, YELLOW, RED, GREEN, BLUE, PINK, BLACK, WHITE
    }
    
    // grid size
    public static int GRID_SIZE_X = 32, GRID_SIZE_Y = 16;
    // array of buttons
    private JButton [] buttonArray; 
    
    //many parallel arrays - used to track all game elements
    private boolean[][] occupied = new boolean[GRID_SIZE_Y][GRID_SIZE_X];
    private boolean[][] revealed = new boolean[GRID_SIZE_Y][GRID_SIZE_X];
    private Creature[][] creatureAt = new Creature[GRID_SIZE_Y][GRID_SIZE_X];
    private Trap[][] trapAt = new Trap[GRID_SIZE_Y][GRID_SIZE_X];
    private PowerUp[][] powerUpAt = new PowerUp[GRID_SIZE_Y][GRID_SIZE_X];
    private boolean[][] sinkholes = new boolean[GRID_SIZE_Y][GRID_SIZE_X];
    
    // Full list of possible creatures to spawn
    // Each creatures shape is defined by the list of points
    // To make it easier to understand, the points have been indented to match the game grid
    Creature[] creatures = {
    		
    		
    		new Creature("Squid", new Point[] {
    							new Point(1,0), new Point(2,0), new Point(3,0),
    		    new Point(0,1), new Point(1,1), new Point(2,1), new Point(3,1), new Point(4,1),
    		    new Point(0,2), 				new Point(2,2),					new Point(4,2),
    		    				new Point(1,3), 				new Point(3,3),
    		    				new Point(1,4), 				new Point(3,4)		
    		}),
    		   
    		new Creature("Manta Ray", new Point[] {
    			new Point(0,0), 												new Point(4,0),
    		    				new Point(1,1), 				new Point(3,1),
    		    new Point(0,2), new Point(1,2), new Point(2,2), new Point(3,2), new Point(4,2),
    		    								new Point(2,3)
    		}),
    		
    		new Creature("Small Fish", new Point[] {
    		    new Point(0,0), 				new Point(2,0),
    		    				new Point(1,1)
    		}),
    		
    		new Creature("Small Fish2", new Point[] {
        		    new Point(0,0), new Point(1,0),
        		    				new Point(1,1)
        		}),
    		
    		new Creature("Small Fish3", new Point[] {
        		    new Point(0,0), new Point(1,0), new Point(2,0)
        		}),
    		
    		new Creature("Eel", new Point[] {
        		    new Point(0,0), new Point(1,0), new Point(2,0), new Point(3,0)
        		}),
    		
    		new Creature("Small Fish4", new Point[] {
        		    new Point(0,0), new Point(1,0)    
        		}),
    		
    		new Creature("Starfish", new Point[] {
    			new Point(0,0), 				new Point(2,0),
    		    				new Point(1,1),
    		    new Point(0,2),					new Point(2,2),
    		}),
    		
    		new Creature("Seahorse", new Point[] {
    							new Point(1,0),
    			new Point(0,1), new Point(1,1),
    							new Point(1,2),
    							new Point(1,3), new Point(2,3)
    		}),
    		
    		new Creature("Jellyfish", new Point[] {
    			    				new Point(1,0), new Point(2,0), new Point(3,0),
    			    new Point(0,1), new Point(1,1), new Point(2,1), new Point(3,1), new Point(4,1),
    			    new Point(0,2),					new Point(2,2),					new Point(4,2),
    			    new Point(0,3),					new Point(2,3),					new Point(4,3),
    			    				new Point(1,4),					new Point(3,4),		
    			    				new Point(1,5),					new Point(3,5),
    			    new Point(0,6),					new Point(2,6),					new Point(4,6),
    			    new Point(0,7),					new Point(2,7),					new Point(4,7),
    			}),
    		
    };
    
    // blank 1x1 point for traps and powerups
    Point[] singlePoint = new Point[] { new Point(0,0) };
    
    // list of trap types
    Trap[] traps = 
    {
    	    new Trap("Sea Mine", singlePoint, Trap.TRAP_TYPE.SEA_MINE),
    	    new Trap("Bombfish", singlePoint, Trap.TRAP_TYPE.BOMBFISH),
    	    new Trap("Kelp", singlePoint, Trap.TRAP_TYPE.KELP)
    };
    
    // list of powerup types
    PowerUp[] powerUps = 
    {
    		new PowerUp("Health Boost", singlePoint, PowerUp.POWERUP_TYPE.HEALTH_BOOST),
    		new PowerUp("Extra Turn", singlePoint, PowerUp.POWERUP_TYPE.EXTRA_TURN),
    		new PowerUp("Reveal", singlePoint, PowerUp.POWERUP_TYPE.REVEAL),
    };
    
    // method to create the menubar at the top of the game
    public JMenuBar createMenu() 
    {
    	// new menu bar and blank menu item
        JMenuBar menuBar  = new JMenuBar();;
        JMenuItem menuItem;
        
        // top level menu entry
        JMenu newGameMenu = new JMenu("New Game");
        menuBar.add(newGameMenu);

        // drop down options for new game
        menuItem = new JMenuItem("Free Play");
        menuItem.addActionListener(this);
        newGameMenu.add(menuItem);

        menuItem = new JMenuItem("Easy");
        menuItem.addActionListener(this);
        newGameMenu.add(menuItem);

        menuItem = new JMenuItem("Medium");
        menuItem.addActionListener(this);
        newGameMenu.add(menuItem);
        
        menuItem = new JMenuItem("Hard");
        menuItem.addActionListener(this);
        newGameMenu.add(menuItem);
        
        menuItem = new JMenuItem("Impossible");
        menuItem.addActionListener(this);
        newGameMenu.add(menuItem);
        
        // top level menu entry
        JMenu optionsMenu = new JMenu("Options");
        menuBar.add(optionsMenu);
        
        // drop down options
        menuItem = new JMenuItem("Save");
        menuItem.addActionListener(this);
        optionsMenu.add(menuItem);
        
        menuItem = new JMenuItem("Load");
        menuItem.addActionListener(this);
        optionsMenu.add(menuItem);
        
        menuItem = new JMenuItem("Help");
        menuItem.addActionListener(this);
        optionsMenu.add(menuItem);
        
        menuItem = new JMenuItem("Exit");
        menuItem.addActionListener(this);
        optionsMenu.add(menuItem);
        
        // return the menu bar
        return menuBar;
    }

    // returns the gui container
    public Container createContentPane() 
    {	
        // main panel with game grid
        JPanel mainPanel = new JPanel(new BorderLayout());

        // top panel to add a slight border, and sets background for the timer and player info
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Adds a small border so text and timer are not close to edge
        topPanel.setBackground(Color.DARK_GRAY); // Set background to dark gray

        // player 1 info - will display on the left of the screen
        player1.setLabel(new JLabel("Player 1: HP 100 | Score: 0")); // Score and HP displayed as default values initially
        player1.getLabel().setForeground(Color.WHITE); // Text set to white
        JPanel player1Panel = new JPanel(); // New panel for player 1 info
        player1Panel.setOpaque(false); // Makes background transparent
        player1Panel.add(player1.getLabel());

        // player 2 info - will display on the right of the screen
        player2.setLabel(new JLabel("Player 2: HP 100 | Score: 0")); // Score and HP displayed as default values initially
        player2.getLabel().setForeground(Color.WHITE); // Text set to white
        JPanel player2Panel = new JPanel(); // New panel for player 1 info
        player2Panel.setOpaque(false); // Makes background transparent
        player2Panel.add(player2.getLabel());

        // centre panel for timer and turn display
        timerLabel = new JLabel("10.00", SwingConstants.CENTER); // Timer
        timerLabel.setFont(new Font("Arial", Font.BOLD, 22)); // Sets font and font size
        timerLabel.setForeground(Color.WHITE); // Sets text to white
        
        turnLabel = new JLabel("Turn: Player 1", SwingConstants.CENTER); // Turn display - initially player 1
        turnLabel.setFont(new Font("Arial", Font.BOLD, 16)); // Sets font and font size
        turnLabel.setForeground(Color.WHITE); // Sets text to white
        
        JPanel centerPanel = new JPanel(new GridLayout(2, 1)); 
        centerPanel.setOpaque(false);
        centerPanel.add(timerLabel);
        centerPanel.add(turnLabel);

        // add to top panel
        topPanel.add(player1Panel, BorderLayout.WEST);
        topPanel.add(centerPanel, BorderLayout.CENTER);
        topPanel.add(player2Panel, BorderLayout.EAST);

        // main game grid
        int numButtons = GRID_SIZE_X * GRID_SIZE_Y; // Sets the number of buttons for the grid
        JPanel grid = new JPanel(new GridLayout(GRID_SIZE_Y, GRID_SIZE_X)); // Creates the grid using predefined size
        
        // creates and populates an array of buttons
        buttonArray = new JButton[numButtons]; // Creates an array of buttons
        
        for (int i=0; i<numButtons; i++) // loop for number of buttons
        {
            buttonArray[i] = new JButton(" "); // adds a new button to the array
            buttonArray[i].setActionCommand("" + i); // sets the action command
            buttonArray[i].addActionListener(this); // adds an action listener
            grid.add(buttonArray[i]); // adds the button to the grid
        }

        // add HUD and GRID to main container
        mainPanel.add(topPanel, BorderLayout.NORTH);
        mainPanel.add(grid, BorderLayout.CENTER);
        
        // returns the GUI
        return mainPanel; 
    }

    
    // this method handles events from the menu and the board.
    public void actionPerformed(ActionEvent e) 
    {	
    	// gets the name of the class
        String classname = getClassName(e.getSource());
        JComponent component = (JComponent)(e.getSource());
        
        // if the class is JMenuItem...
        if (classname.equals("JMenuItem"))
        {	
        	// gets the text from the menu item
            JMenuItem menusource = (JMenuItem)(e.getSource());
            String menutext  = menusource.getText();
            
            
            
            // Determine which menu option was chosen
            
            // NEW GAME
            if (menutext.equals("Free Play"))
            {	
            	// lots of sinkholes, no traps and no powerups
            	// sinkholes aren't dangerous without traps, they just speed up the game
            	maxSinkholes = 50;
            	maxPowerUps = 0;
            	maxTraps = 0;
            	newGame();
            }
            else if (menutext.equals("Easy"))
            {	
            	// less traps, more powerups and sinkholes
            	maxSinkholes = 30;
            	maxPowerUps = 20;
            	maxTraps = 10;
            	newGame();
            }
            else if (menutext.equals("Medium"))
            {	
            	// fewer powerups and sinkholes, more traps
            	maxSinkholes = 20;
            	maxPowerUps = 10;
            	maxTraps = 20;
            	newGame();
            }
            else if (menutext.equals("Hard"))
            {	
            	// sinkholes can be devastating if they hit lots of traps, reduced for balance
            	maxSinkholes = 10;
            	maxPowerUps = 10;
            	maxTraps = 50;
            	newGame();
            }
            else if (menutext.equals("Impossible"))
            {	
            	// good luck
            	maxSinkholes = 20;
            	maxPowerUps = 0;
            	maxTraps = 140;
            	newGame();
            }
            
            // OPTIONS
            else if (menutext.equals("Save"))
            {
            	if (gameTimer != null) 
            	{
                    gameTimer.stop();
                }
                saveGame();
            }
            
            else if (menutext.equals("Load"))
            {
            	if (gameTimer != null) 
            	{
                    gameTimer.stop();
                }
                loadGame();
            }
            
             
            
            // the exit option has an additional check to ensure the user has saved the game first
            else if (menutext.equals("Exit")) 
            {
            	int result = JOptionPane.showConfirmDialog(null, "Do you want to save your game before exiting?", "Confirmation", JOptionPane.YES_NO_OPTION);
            	if (result == JOptionPane.YES_OPTION)
            	{
            	    saveGame();
            	    System.exit(0);
            	} 
            	else if (result == JOptionPane.NO_OPTION) 
            	{
            		System.exit(0);
            	}
                
            }
        }
        // handle the event from the user clicking on a command button
        else if (classname.equals("JButton"))
        {
            JButton button = (JButton)(e.getSource());
            int bnum = Integer.parseInt(button.getActionCommand());
            int row = bnum / GRID_SIZE_X;
            int col = bnum % GRID_SIZE_X;
                   
            // calls the click square with the row column, and not a sinkhole action
            clickSquare(row, col, false);
        }  
    }
    
    // method to start the timer
    private void startTimer()
    {
        // stop previous timer
        if (gameTimer != null) 
        {
            gameTimer.stop();
        }
        // reset timer
        timeLeft = 10; 
        timerLabel.setText("00:10");
        timerLabel.setForeground(defaultTimerColor);
        
        // update UI for current player
        highlightActivePlayer(); 
        
        // creates the timer, counting down from 10
        gameTimer = new Timer(1000, e -> 
        {
            timeLeft--;
            
            int mins = timeLeft / 60;
            int secs = timeLeft % 60;
            timerLabel.setText(String.format("%02d:%02d", mins, secs));

            // if under 3 seconds, flash red
            if (timeLeft <= 3 && timeLeft > 0)
            {
                flashState = !flashState;
                timerLabel.setForeground(flashState ? Color.RED : Color.WHITE);
            }

            // if timer runs out, swap turns
            if (timeLeft <= 0)
            {
                timerLabel.setForeground(Color.RED);
                gameTimer.stop();
                updateTurn();
                if (vsComputer) performComputerMove();
            }
        });
        
        // starts the timer
        gameTimer.start();
    }
    
    // method to highlight the name of the active player
    private void highlightActivePlayer() 
    {
        if (player1Turn) 
        {
            player1.getLabel().setForeground(Color.GREEN);
            player2.getLabel().setForeground(Color.WHITE);
        } 
        else
        {
        	player1.getLabel().setForeground(Color.WHITE);
        	player2.getLabel().setForeground(Color.GREEN);
        }
    }

    // returns the class name
    protected String getClassName(Object o) 
    {
        String classString = o.getClass().getName();
        int dotIndex = classString.lastIndexOf(".");
        return classString.substring(dotIndex+1);
    }

    // creates and displays the gui
    private static void createAndShowGUI() 
    {
        // create and set up the window
        JFrame frame = new JFrame("Project Nova");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // create and set up the content pane
        MainGame Connectgui = new MainGame();
        frame.setJMenuBar(Connectgui.createMenu());
        frame.setContentPane(Connectgui.createContentPane());

        // display the window, setting the size
        frame.setSize(1920, 1080);
        frame.setVisible(true);
    }
    
    // method to set a gui grid square at row, col to display a certain colour
    public boolean setGuiSquare(int row, int col, GRID_COLOUR colour)
    {
        int bnum = row * GRID_SIZE_X + col;
        if (bnum >= (GRID_SIZE_X * GRID_SIZE_Y))
        {
            return false;
        }
        else
        {
            switch(colour)
            {
                case RED:
                    buttonArray[bnum].setBackground(Color.red);
                    break;
                case YELLOW:
                    buttonArray[bnum].setBackground(Color.yellow);
                    break;
                case BLANK:
                    buttonArray[bnum].setBackground(Color.gray);
                    break;
                case GREEN:
                    buttonArray[bnum].setBackground(Color.green);
                    break; 
                case BLUE:
                    buttonArray[bnum].setBackground(Color.blue);
                    break;
                case PINK:
                    buttonArray[bnum].setBackground(Color.pink);
                    break;
                case BLACK:
                	buttonArray[bnum].setBackground(Color.black);
                    break;
                case WHITE:
                	buttonArray[bnum].setBackground(Color.white);
                    break;
                default:
                    buttonArray[bnum].setBackground(Color.gray);
                    break;
                }
        }
        return true;
    }
    
    // main function to display gui
    public static void main(String[] args) 
    {
        // schedule a job for the event-dispatching thread:
        // creating and showing this application's GUI.
        javax.swing.SwingUtilities.invokeLater(new Runnable() 
        {
            public void run() 
            {
                createAndShowGUI();
            }
        });
    }
    
    // method to start a new game
    public void newGame()
    {
    	// option of singleplayer or multiplayer
    	String[] options = {"Singleplayer", "Multiplayer"};
        int selection = JOptionPane.showOptionDialog(null, "Singleplayer or multiplayer?:", "Selection", 
                JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, options, options);
        if (selection == 0)
        {
            vsComputer = true;
        } 
        else if (selection == 1)
        {
            vsComputer = false;
        }
        
        // tells the user the game has started
    	JOptionPane.showMessageDialog(null, "New game started! The timer will begin after you click OK."); 
    	
    	// sets player 1 as first turn
    	player1Turn = true;
    	// highlight player
    	highlightActivePlayer();
    	// set game started to true
        gameStarted = true;
        
        // asks the user(s) to enter their name
        player1.setName(JOptionPane.showInputDialog(null, "Player 1, please enter your name:"));
        if (!vsComputer) player2.setName(JOptionPane.showInputDialog(null, "Player 2, please enter your name:"));
        else player2.setName("Computer");
        
        // reset both players
        player1.reset();
        player2.reset();
        
        // reset board
        for (int targetRow  = 0; targetRow  < GRID_SIZE_Y; targetRow ++) 
        {
            for (int targetCol = 0; targetCol < GRID_SIZE_X; targetCol++) 
            {
                occupied[targetRow][targetCol] = false;
                revealed[targetRow][targetCol] = false;
                creatureAt[targetRow][targetCol] = null;
                trapAt[targetRow][targetCol] = null;
                powerUpAt[targetRow][targetCol] = null;
                sinkholes[targetRow][targetCol] = false;
                setGuiSquare(targetRow, targetCol, GRID_COLOUR.BLANK);
            }
        }
        // start the timer
        startTimer();
        // randomly place game elements
        placeCreaturesRandomly();
        placeTrapsRandomly();
        placePowerUpsRandomly();
        placeSinkHolesRandomly();
        
        // DEBUG used to see occupied squares
        //for (int r = 0; r < GRID_SIZE_Y; r++) {
            //for (int c = 0; c < GRID_SIZE_X; c++) {
                //if (occupied[r][c]) {
                    //setGuiSquare(r, c, GRID_COLOUR.RED);
               // }
           // }
        //}
        
    }
    
    // called each time a square is clicked
    // the sinkhole boolean is used for later checks, as sinkholes use this method
    public void clickSquare(int row, int col, boolean sinkhole)
    {     
    	// ensures the game has started
    	if (!gameStarted)
    	{
    		JOptionPane.showMessageDialog(null, "You must select new game, or load a save game first.");
    		return;
    	}
        
    	// checks if the button has already been clicked, if it has, ignore this click
    	if (buttonAlreadyClicked(row, col)) return;
        
    	// sets the square to revealed - used for saving and loading
    	revealed[row][col] = true;
        
    	// if a creature is on clicked square
    	if (creatureAt[row][col] != null)
    	{	
    		// finds creature
    		Creature hitCreature = creatureAt[row][col];
        	
    		// increases the number of times the whole creature has been hit
    		hitCreature.hits++;
    		
    		// increment score, assign grid colour
    		if (player1Turn)
    		{
    			player1.setScore(player1.getScore() + 5);
    			setGuiSquare(row, col, GRID_COLOUR.GREEN);  
    		}
    		else
    		{
    			player2.setScore(player2.getScore() + 5);
    			setGuiSquare(row, col, GRID_COLOUR.BLUE); 
    		}
        	  
        	  
    		// check if creature is fully revealed
    		if (hitCreature.hits >= hitCreature.shape.length) {
    			hitCreature.found = true;
    			// set all squares of this creature to pink
    			for (Point offset : hitCreature.rotatedOffsets) {
    				int anchorRow = hitCreature.anchorRow + offset.x;
    				int anchorCol = hitCreature.anchorCol + offset.y;
    				setGuiSquare(anchorRow, anchorCol, GRID_COLOUR.PINK);
    			}
    			// extra 5 points for fully revealing creature
    			if (player1Turn) player1.setScore(player1.getScore() + 5);
    			else player2.setScore(player2.getScore() + 5);
    		}
        	
    		// restart timer
    		startTimer();
          
    	}
    	// if a trap is clicked
    	else if (trapAt[row][col] != null) 
    	{
    		// determine the type of trap
    		Trap trap = trapAt[row][col];
    		switch(trap.type) {
    			case SEA_MINE:
    				// remove 20hp
    				if (player1Turn) player1.setHP(player1.getHP() - 20);
    				else player1.setHP(player1.getHP() - 20);
    				
    				// pause timer and display message
    				gameTimer.stop();
    				JOptionPane.showMessageDialog(null, "Boom! You hit a sea mine. Lose 20 HP.");
    				
    				// if not a sinkhole action, swap turns
    				if (!sinkhole) updateTurn();
    				break;
    				
    			case BOMBFISH:
    				// remove 10 score
    				if (player1Turn) player1.setScore(player1.getScore() - 10);
    				else player2.setScore(player2.getScore() - 10);
    				
    				// pause timer and display message
    				gameTimer.stop();
    				JOptionPane.showMessageDialog(null, "Bombfish! Lose 10 points.");
    				
    				// if not a sinkhole action, swap turns
    				if (!sinkhole) updateTurn();
    				break;
    			case KELP:
    				// pause timer and display message
    				gameTimer.stop();
    				JOptionPane.showMessageDialog(null, "You got tangled in kelp! You'll miss your next turn.");

    				// set skip flag for the current player
    				if (player1Turn) player1.setSkippedTurn(true);
    				else player2.setSkippedTurn(true);
    				
    				// if not sinkhole action, manually swap turns
    				// does not use update turn method, as that contains a check which would immediately override kelp action
    				if (!sinkhole) player1Turn = !player1Turn;
    				if (!sinkhole) updateTurnUI();
    				break;
    		}
    		// show trap hit visually
    		setGuiSquare(row, col, GRID_COLOUR.RED);
    		
    		// remove trap
    		trapAt[row][col] = null; 
    	}
    	// if a powerup is clicked
    	else if (powerUpAt[row][col] != null) 
    	{	
    		//determine the type of powerup
    		PowerUp powerUp = powerUpAt[row][col];
    		switch(powerUp.type) {
    			case HEALTH_BOOST:
    				// add 20hp
    				if (player1Turn) player1.setHP(player1.getHP() + 20);
        	  		else player2.setHP(player2.getHP() + 20);
    				
    				// pause timer and display message
        	  		gameTimer.stop();
        	  		JOptionPane.showMessageDialog(null, "Health boost! Gain 20 HP.");
        	  		
        	  		// restart timer
        	  		startTimer();
        	  		break;
        	  		
    			case EXTRA_TURN:
    				// set flag for extra turn
        	  		if (player1Turn) player1.setExtraTurn(true);
    	            else player2.setExtraTurn(true);
        	  		
        	  		// pause timer and display message
        	  		gameTimer.stop();
        	  		JOptionPane.showMessageDialog(null, "Power up! Extra turn.");
        	  		
        	  		// restart timer
        	  		startTimer();
        	  		break;
        	  		
        	  	case REVEAL:
        	  		// reveal a random creature tile
        	  		revealRandomCreatureTile();
        	  		
        	  		// pause timer and display message
        	  		gameTimer.stop();
        	  		JOptionPane.showMessageDialog(null, "Power up! A random part of a creature has been revealed...");
        	  		
        	  		// restart timer
        	  		startTimer();
    		}
    		// display powerup
    		setGuiSquare(row, col, GRID_COLOUR.WHITE);
    		// remove powerup
    		powerUpAt[row][col] = null; 
    	}
    	// if a sinkhole is clicked
    	else if (sinkholes[row][col])
    	{	
    		// reveal sinkhole
    		setGuiSquare(row, col, GRID_COLOUR.BLACK);
    		
    		// pause timer and display message
    		gameTimer.stop();
    		JOptionPane.showMessageDialog(null, "Sinkhole! The surrounding 8 squares will be activated at once...");
        	  
    		// loops to click all neighbours
    		for (int dr = -1; dr <= 1; dr++)
    		{
    			for (int dc = -1; dc <= 1; dc++) 
    			{

    				// skip the sinkhole square
    				if (dr == 0 && dc == 0) continue;

    				int rr = row + dr;
    				int cc = col + dc;
        			  
    				// skip out-of-bounds positions
    				if (rr < 0 || rr >= GRID_SIZE_Y) continue;
    				if (cc < 0 || cc >= GRID_SIZE_X) continue;
        			  
    				// skip already-clicked squares
    				if (buttonAlreadyClicked(rr, cc)) continue;

    				// mimic user click on neighbour square
    				// as this is a sinkhole action, boolean is true
    				clickSquare(rr, cc, true);
    			}
    		}
    		// restart timer
    		startTimer();
    	}
    	// if nothing here...
    	else 
    	{
    		// miss — mark as yellow, swap turns
    		setGuiSquare(row, col, GRID_COLOUR.YELLOW);
    		if (!sinkhole) updateTurn();
    	}
        // update the scoreboard
    	updateScoreDisplay();
          
    	// check hp, end game if below 0
    	if (player1.getHP() <= 0) {
    		JOptionPane.showMessageDialog(null, player1.getName() + " Lost all their health! " + player2.getName() + " wins!");
    		gameStarted = false;
    		return;
    	}
    	if (player2.getHP() <= 0) {
    		JOptionPane.showMessageDialog(null, player2.getName() + " Lost all their health! " + player1.getName() + " wins!");
    		gameStarted = false;
    		return;
    	}
    	// check if all creatures are found, end game if so
    	if (allCreaturesFound()) {
    		endGame();
    	}
    	// if playing computer, call computer to make a move
    	if (!player1Turn && vsComputer && !sinkhole) {
    		performComputerMove();
    	}
    }
    
    // method to check if button has been clicked
    // uses grid background colour
    private boolean buttonAlreadyClicked(int row, int col) {
        Color current = buttonArray[row * GRID_SIZE_X + col].getBackground();
        if (current != Color.gray)
        {
        	return true;
        }
        else return false;
    }
    
    // method to swap turns
    // includes skipped and extra turn checks
    private void updateTurn() {
        // check if next player should be skipped - priority over extra turn
        if (!player1Turn && player1.hasSkippedTurn()) {
            player1.setSkippedTurn(false); 
            player1Turn = false;        
            startTimer();
            return;
        } 
        else if (player1Turn && player2.hasSkippedTurn()) {
        	player2.setSkippedTurn(false); 
            player1Turn = true;         
            startTimer();
            return;
        }
        // check if player has bonus turn
        else if (!player1Turn && player2.hasExtraTurn()) {
        	player2.setExtraTurn(false);
            player1Turn = false;         
            startTimer();
            return;
        }
        else if (player1Turn && player1.hasExtraTurn()) {
        	player1.setExtraTurn(false); 
            player1Turn = true;         
            startTimer();
            return;
        }
        
        // if no traps/powerups, swap turns, update ui
        player1Turn = !player1Turn;
        updateTurnUI();
        
    }
    
    // method to update the turn ui - displays current turn, and notifies the user(s)
    private void updateTurnUI() {
        turnLabel.setText(player1Turn ? "Turn: Player 1" : "Turn: Player 2");
        highlightActivePlayer(); 
        if (player1Turn) JOptionPane.showMessageDialog(null, player1.getName() + ", its your turn!");
        else JOptionPane.showMessageDialog(null, player2.getName() + ", its your turn!");
        
        startTimer();
    }
    
    // updates the scores
    private void updateScoreDisplay() {
    	player1.updateLabel();
    	player2.updateLabel();
    }
    
    // method to randomly pick a square
    // this is a very simple computer - a more complex version could be implemented, possibly for the harder difficulties?
    private void performComputerMove() {
        // delay for realism
    	Timer aiDelay = new Timer(800, e -> 
    	{
            ((Timer)e.getSource()).stop();
            
            // pick random gray tile
            ArrayList<Point> options = new ArrayList<>();

            for (int r = 0; r < GRID_SIZE_Y; r++) 
            {
            	for (int c = 0; c < GRID_SIZE_X; c++) 
            	{
                    if (buttonArray[r * GRID_SIZE_X + c].getBackground() == Color.gray) 
                    {
                        options.add(new Point(r, c));
                    }
                }
            }

            if (options.size() == 0) return;

            Point pick = options.get(new Random().nextInt(options.size()));
            
            // clicks the random square
            clickSquare(pick.x, pick.y, false);
            
        });
        aiDelay.setRepeats(false);
        aiDelay.start();
    }
    
    // method to randomly place creatures
    private void placeCreaturesRandomly() {
        Random random = new Random();
        
        // for each type of creature
        for (Creature creature : creatures)
        {  	
        	// initially not placed
        	boolean placed = false;

        	while (!placed) 
        	{	
            	// pick random rotation
                int[] rotations = {0, 90, 180, 270};
                int rotation = rotations[random.nextInt(rotations.length)];

                // apply rotation
                Point[] rotatedCreature = rotateCreature(creature.shape, rotation);
            	
                // assigns the rotated offsets
                creature.rotatedOffsets.clear();
                for (Point p : rotatedCreature )
                {
                    creature.rotatedOffsets.add(new Point(p.x, p.y));
                }
            	
                // pick a random anchor cell
                int baseRow = random.nextInt(GRID_SIZE_Y);
                int baseCol = random.nextInt(GRID_SIZE_X);
                
                // checks if creature cannot be placed
                if (!canPlaceCreature(rotatedCreature, baseRow, baseCol))
                    continue;

                // place creature on board
                for (Point offset : rotatedCreature) {

                    int targetRow = baseRow + offset.x;
                    int targetCol = baseCol + offset.y;

                    creatureAt[targetRow][targetCol] = creature;
                    occupied[targetRow][targetCol] = true;
                    
                    
                    // DEBUG - this line was used to reveal all creatures immediately when testing
                    //setGuiSquare(targetCol, targetRow, GRID_COLOUR.RED);
                }
                
                // sets placed to true
                placed = true;
                // saves creature's anchor
                creature.anchorRow = baseRow;
                creature.anchorCol = baseCol;
            }
            
        }
    }
    
    // method to rotate creatures
    private Point[] rotateCreature(Point[] original, int rotation) {
        Point[] rotated = new Point[original.length];
        
        // for every point of the creature
        for (int i = 0; i < original.length; i++) {
            int x = original[i].x;
            int y = original[i].y;
            
            // apply the new modified coordinates
            switch (rotation) {
                case 90:  rotated[i] = new Point(y, -x); break;
                case 180: rotated[i] = new Point(-x, -y); break;
                case 270: rotated[i] = new Point(-y, x); break;
                default:  rotated[i] = new Point(x, y); break;
            }
        }
        // normalises shape - ensures smallest x and y value is at (0,0)
        return normaliseShape(rotated);
    }
    
    // method to place smallest x and y value at (0,0)
    private Point[] normaliseShape(Point[] shape) {
        
    	// start at largest possible integer
        int minX = Integer.MAX_VALUE;
        int minY = Integer.MAX_VALUE;
        
        // standard algorithm for find minimum
        for (Point p : shape) {
            if (p.x < minX) minX = p.x;
            if (p.y < minY) minY = p.y;
        }
        
        // creates new, normalised shape
        Point[] normalised = new Point[shape.length];
        for (int i = 0; i < shape.length; i++) {
            normalised[i] = new Point(shape[i].x - minX, shape[i].y - minY);
        }
        
        // returns normalised shape
        return normalised;
    }
    
    // method to check a creature can be placed
    private boolean canPlaceCreature(Point[] shape, int baseRow, int baseCol) {
    	
    	// for every point in shape
        for (Point offset : shape) {
        	
        	// current square to check - offset from anchor point
            int row = baseRow + offset.x;
            int col = baseCol + offset.y;

            // out of bounds check
            if (row < 0 || row >= GRID_SIZE_Y || col < 0 || col >= GRID_SIZE_X)
                return false;

            // ensures creature is not near other creatures, including diagonals
            for (int r = row - 1; r <= row + 1; r++) {
                for (int c = col - 1; c <= col + 1; c++) {

                    // stay in bounds
                    if (r < 0 || r >= GRID_SIZE_Y || c < 0 || c >= GRID_SIZE_X)
                        continue;

                    // any neighbouring cell already occupied?
                    if (occupied[r][c])
                        return false;
                }
            }
        }
        
        // if can be placed...
        return true;
    }
    
    // method to place traps randomly
    private void placeTrapsRandomly() {
        Random random = new Random();
        int numPerTrap;
        
        // for each type of trap
        for (Trap trapTemplate : traps) {
            int count = 0;
            // number of traps for this type is random, maximum defined by difficulty
            numPerTrap = random.nextInt(maxTraps + 1);
            
           // while the number of traps currently placed is less than number of traps to be placed...
            while (count < numPerTrap) {
            	
            	//pick a random square
                int row = random.nextInt(GRID_SIZE_Y);
                int col = random.nextInt(GRID_SIZE_X);
                
                // check if valid square
                if (!canPlace(trapTemplate.shape, row, col))
                    continue;

                // create a new trap instance for this placement
                Trap trapInstance = new Trap(trapTemplate.name, trapTemplate.shape, trapTemplate.type);
                
                // places said trap on grid, occupies the square
                trapAt[row][col] = trapInstance;
                occupied[row][col] = true;
                
                // saves the anchor point
                trapInstance.anchorRow = row;
                trapInstance.anchorCol = col;
                
                // increment num placed traps
                count++;
            }
        }
    }
    
    // method to place powerups randomly
    // works in the same way as traps
    // used two methods due to number of distinct variables (template etc)
    private void placePowerUpsRandomly() {
    	Random random = new Random();
    	int maxPerPowerUp;
    	
    	for (PowerUp powerUpTemplate : powerUps)
    	{
            int count = 0;
            maxPerPowerUp = random.nextInt(maxPowerUps + 1);
            
           
            while (count < maxPerPowerUp) 
            {
                int row = random.nextInt(GRID_SIZE_Y);
                int col = random.nextInt(GRID_SIZE_X);

                if (!canPlace(powerUpTemplate.shape, row, col))
                    continue;

                PowerUp powerUpInstance = new PowerUp(powerUpTemplate.name, powerUpTemplate.shape, powerUpTemplate.type);

                powerUpAt[row][col] = powerUpInstance;
                occupied[row][col] = true;

                powerUpInstance.anchorRow = row;
                powerUpInstance.anchorCol = col;
                count++;
            }
        }
   
    	
    }
    
    // sinkholes also work in a similar fashion
    // slightly simpler as they only have one type
    private void placeSinkHolesRandomly() {
    	Random random = new Random();
    	int count = 0;
 
        while (count < maxSinkholes)
        {
                int row = random.nextInt(GRID_SIZE_Y);
                int col = random.nextInt(GRID_SIZE_X);

                if (!canPlace(singlePoint, row, col))
                    continue;

                
                // key difference - saved as boolean, not object
                sinkholes[row][col] = true;
                occupied[row][col] = true;

                count++;
        }
     }
    
    // method to check if game element can be placed
    // overcomplicated for what is needed, however would work with multi-square elements if a future developer wanted that
    // essentially check to see if square is occupied, game elements inherently need to be next to others to make it interesting
    private boolean canPlace(Point[] shape, int baseRow, int baseCol) {
        for (Point offset : shape)
        {
            int row = baseRow + offset.x;
            int col = baseCol + offset.y;

            if (row < 0 || row >= GRID_SIZE_Y || col < 0 || col >= GRID_SIZE_X)
                return false;

            if (occupied[row][col]) return false;
        }
        return true;
    }

    // method for reveal powerup
    private void revealRandomCreatureTile() {
    	// create arraylist for all hidden creature squares
        ArrayList<Point> hiddenParts = new ArrayList<>();
        
        // loop through grid to find all unrevealed creatures
        for (int r = 0; r < GRID_SIZE_Y; r++)
        {
            for (int c = 0; c < GRID_SIZE_X; c++)
            {
                if (creatureAt[r][c] != null) 
                {
                    Color color = buttonArray[r * GRID_SIZE_X + c].getBackground();
                    // unrevealed creature squares are still grey
                    if (color == Color.gray)
                    {
                        hiddenParts.add(new Point(r, c));
                    }
                }
            }
        }
        
        // pick a random square
        Random rand = new Random();
        Point pick = hiddenParts.get(rand.nextInt(hiddenParts.size()));
        
        // reveal to user(s)
        setGuiSquare(pick.x, pick.y, GRID_COLOUR.PINK);
    }
    
    // method to check if all creatures have been found
    private boolean allCreaturesFound() {
    	
    	// total num creatures
    	int totalCreatures = creatures.length;
    	
    	// running total standard algorithm to count how many creatures have been found
    	int totalCreaturesFound = 0;
        for (Creature creature : creatures) 
        {
            if (creature.found) totalCreaturesFound++;
        }
        // check if num creatures found matches total creatures
        if (totalCreatures == totalCreaturesFound) return true;
        else return false;
    }
    
    // method to end game - checks scores, displays winning message
    private void endGame()
    {
    	if (player1.getScore() > player2.getScore()) JOptionPane.showMessageDialog(null, "All creatures found, " + player1.getName() + " wins!");
    	else if (player2.getScore() > player1.getScore()) JOptionPane.showMessageDialog(null, "All creatures found, " + player1.getName() + " wins!");
    	else JOptionPane.showMessageDialog(null, "All creatures found, it was a tie!");
    	gameStarted = false;
    	gameTimer.stop();
    }
    
    // method to save game
    public void saveGame() {
        if (!gameStarted) {
            JOptionPane.showMessageDialog(null, "No game to save.");
            return;
        }
        
        // uses a file chooser so user can save wherever they like
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Save Game");
        // asks user to choose a file name
        chooser.setSelectedFile(new File(JOptionPane.showInputDialog(null, "Please enter the name of the save:") + ".dat"));
        
        // ensures name is valid
        if (chooser.showSaveDialog(null) != JFileChooser.APPROVE_OPTION)
            return;
        
        // tries to save game
        try
        {
        	// creates a game state object - this contains all necessary information about the current game
            GameState state = new GameState();

            state.player1.setName(player1.getName());
            state.player2.setName(player2.getName());
            
            state.player1.setHP(player1.getHP());
            state.player2.setHP(player2.getHP());
            
            state.player1.setScore(player1.getScore());
            state.player2.setScore(player2.getScore());

            state.player1Turn = player1Turn;
            state.vsComputer = vsComputer;
            state.gameStarted = gameStarted;

            state.gridX = GRID_SIZE_X;
            state.gridY = GRID_SIZE_Y;

            state.occupied = occupied;
            state.revealed = revealed;
            state.creatureAt = creatureAt;
            state.trapAt = trapAt;
            state.powerUpAt = powerUpAt;
            state.sinkholes = sinkholes;

            state.timeLeft = 10;
            
            // places game state in file
            ObjectOutputStream out = new ObjectOutputStream(
                new FileOutputStream(chooser.getSelectedFile())
            );
            out.writeObject(state);
            out.close();
            
            // notifies user if success
            JOptionPane.showMessageDialog(null, "Game Saved Successfully!");
            
        }
        // notifies user of error
        catch (Exception ex)
        {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Failed to save game.");
        }
    }
    
    // method to load game
    public void loadGame() {
    	// uses a file chooser so user can choose specific file
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Load Game");
        
        // ensures choice is valid
        if (chooser.showOpenDialog(null) != JFileChooser.APPROVE_OPTION)
            return;
        
        // attempt to load game
        try
        {
        	// input stream from selected file
            ObjectInputStream in = new ObjectInputStream(
                new FileInputStream(chooser.getSelectedFile())
            );
            
            // creates game state object from data in file
            GameState state = (GameState) in.readObject();
            in.close();

            // restore game data
            player1.setName(state.player1.getName());
            player2.setName(state.player2.getName());
            
            player1.setHP(state.player1.getHP());
            player2.setHP(state.player2.getHP());
            
            player1.setScore(state.player1.getScore());
            player2.setScore(state.player2.getScore());

            player1Turn = state.player1Turn;
            vsComputer = state.vsComputer;
            gameStarted = state.gameStarted;

            occupied = state.occupied;
            revealed = state.revealed;
            creatureAt = state.creatureAt;
            trapAt = state.trapAt;
            powerUpAt = state.powerUpAt;
            sinkholes = state.sinkholes;

            timeLeft = state.timeLeft;

            // refresh GUI
            redrawBoard();
            updateScoreDisplay();
            updateTurnUI();
            
            // notifies user if successful
            JOptionPane.showMessageDialog(null, "Game Loaded!");
            
        }
        // notifies user if error
        catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Could not load game.");
        }
    }
    
    // method to redraw game grid after reload
    private void redrawBoard() {
    	// loop through all squares
        for (int row = 0; row < GRID_SIZE_Y; row++) {
            for (int col = 0; col < GRID_SIZE_X; col++) {

                // if not revealed, blank
                if (!revealed[row][col]) {
                    setGuiSquare(row, col, GRID_COLOUR.BLANK);
                    continue;
                }

                // if revealed, show game element/missed square
                if (creatureAt[row][col] != null) {
                    setGuiSquare(row, col, GRID_COLOUR.PINK);
                }
                else if (trapAt[row][col] != null) {
                    setGuiSquare(row, col, GRID_COLOUR.RED);
                }
                else if (powerUpAt[row][col] != null) {
                    setGuiSquare(row, col, GRID_COLOUR.WHITE);
                }
                else if (sinkholes[row][col]) {
                    setGuiSquare(row, col, GRID_COLOUR.BLACK);
                }
                else {
                    setGuiSquare(row, col, GRID_COLOUR.YELLOW);
                }
            }
        }
    }
}