import java.io.Serializable;

// class to save game state - contains all relevant fields
public class GameState implements Serializable {
	Player player1;
	Player player2;

    boolean player1Turn;
    boolean vsComputer;
    boolean gameStarted;

    int gridX = MainGame.GRID_SIZE_X, gridY = MainGame.GRID_SIZE_Y;

    boolean[][] occupied;
    boolean[][] revealed;
    Creature[][] creatureAt;
    Trap[][] trapAt;
    PowerUp[][] powerUpAt;
    boolean[][] sinkholes;

    int timeLeft;
    
    // default constructor - initialises all necessary fields
    public GameState() {
        player1 = new Player();
        player2 = new Player();
        
        occupied = new boolean[gridY][gridX];
        revealed = new boolean[gridY][gridX];
        creatureAt = new Creature[gridY][gridX];
        trapAt = new Trap[gridY][gridX];
        powerUpAt = new PowerUp[gridY][gridX];
        sinkholes = new boolean[gridY][gridX];
    }
}
