import java.awt.Point;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;

// class for creatures - supports multigird
public class Creature implements Serializable {
    String name;
    Point[] shape;
    
    int hits = 0;
    int anchorRow; 
    int anchorCol; 
    boolean found = false;
    
    ArrayList<Point> rotatedOffsets = new ArrayList<>();
    
    public Creature(String name, Point[] shape) {
        this.name = name;
        this.shape = shape;
    }
}

