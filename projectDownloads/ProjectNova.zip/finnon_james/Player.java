import java.io.Serializable;

import javax.swing.JLabel;

// class for players - contains all fields, as well as relevant getters and setters
public class Player implements Serializable{
	
	private String name;
	private int score;
	private int hp;
	
	private JLabel label;
	
	private boolean extraTurn;
	private boolean skippedTurn;
	
	// default constructor - initialises default values
	public Player() {
		name = "";
		score = 0;
		hp = 100;
		extraTurn = false;
		skippedTurn = false;
	}
	
	// method to reset after new game
	public void reset() {
		this.score = 0;
		this.hp = 100;
	    this.extraTurn = false;
	    this.skippedTurn = false;

	    updateLabel();
	}
    // method to update player information label
	public void updateLabel() {
		this.label.setText(name +": HP " + hp + " | Score: " + score);
	}
	 
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	 
	public int getScore() {
		return score;
	}
	 
	public void setScore(int score) {
		this.score = score;
	}
	 
	 
	public int getHP() {
		return hp;
	}

	public void setHP(int hp) {
		this.hp = hp;
	}

    
	public JLabel getLabel() {
		return label;
	}
	 
	public void setLabel(JLabel label) {
		this.label = label;
	}

    
	public boolean hasExtraTurn() {
		return extraTurn;
	}

	public void setExtraTurn(boolean extraTurn) {
		this.extraTurn = extraTurn;
	}

    
	public boolean hasSkippedTurn() {
		return skippedTurn;
	}

	public void setSkippedTurn(boolean skippedTurn) {
		this.skippedTurn = skippedTurn;
	}

}
